from sklearn.metrics import f1_score, accuracy_score
from ExpDataset import MustardDataset
from torch.utils.data import DataLoader
from m2model import M2Model
import torch.nn.functional as F
from torch import nn
import torch
import numpy as np
from torchsummary import summary
import logging
from torch.autograd import Variable


def train(batchsize, epoch):
    data = MustardDataset(datatye='train')
    data_loader = DataLoader(
        data,
        batch_size=batchsize,
        shuffle=True,
        pin_memory=True)
    model = M2Model(batchsize=batchsize).cuda()
    for m in model.modules():
        if isinstance(m, (nn.Linear)):
            nn.init.xavier_uniform_(m.weight)
    lossFun = nn.CrossEntropyLoss().cuda()

    epochs = epoch
    optimizer = torch.optim.Adam(
        model.parameters(), lr=0.001, weight_decay=0.01)

    total = sum([param.nelement() for param in model.parameters()])
    print("Number of parameter: %.2fM" % (total/1e6))
    bestResult = 0

    statePATH = '../../State_dict/m2modelTextBert_textremovetext' +\
        '/best_textremovetext_state_dice.pt'
    modelPATH = '../../State_dict/m2modelTextBert_textremovetext' +\
        '/best_textremovetext_model.pt'

    for _ in range(epochs):
        logger.info('epoch:'+str(_))
        train_step = 0
        for batch in data_loader:
            train_step += 1
            model.train()
            textInput = batch[0][0].cuda().to(torch.float32)
            imageInput = batch[0][1].to(torch.float32).cuda()
            tWavPath = batch[0][2].to(torch.float32).cuda()
            cWavPath = batch[0][3].to(torch.float32).cuda()
            sarLabel = batch[1][0].to(torch.float32).cuda()
            sentLabel = batch[1][1].to(torch.float32).cuda()
            emoLabel = batch[1][2].to(torch.float32).cuda()

            textInput = Variable(textInput, requires_grad=True)
            imageInput = Variable(imageInput, requires_grad=True)
            tWavPath = Variable(tWavPath, requires_grad=True)
            cWavPath = Variable(cWavPath, requires_grad=True)
            sarLabel = Variable(sarLabel, requires_grad=True)
            sentLabel = Variable(sentLabel, requires_grad=True)
            emoLabel = Variable(emoLabel, requires_grad=True)

            sar, sent, emo = \
                model(textInput, imageInput, tWavPath, cWavPath)
            sar = sar.to(torch.float32)
            sent = sent.to(torch.float32)
            emo = emo.to(torch.float32)

            sarArgmax = torch.argmax(sarLabel, dim=-1)
            sentArgmax = torch.argmax(sentLabel, dim=-1)
            emoArgmax = torch.argmax(emoLabel, dim=-1)
            loss1 = lossFun(sar, sarArgmax)
            loss2 = lossFun(sent, sentArgmax)
            loss3 = lossFun(emo, emoArgmax)
            loss = (loss1 + loss2 + loss3)/3
            loss.requires_grad_(True)
            logger.info('loss1:%f loss2:%f loss3:%f loss:%f\n'
                        % (loss1.item(),
                            loss2.item(),
                            loss3.item(),
                            loss.item()))

            if train_step % 2 == 0:
                label_sar = np.argmax(
                    sarLabel.cpu().detach().numpy(), axis=-1)
                label_sent = np.argmax(
                    sentLabel.cpu().detach().numpy(), axis=-1)
                label_emo = np.argmax(
                    emoLabel.cpu().detach().numpy(), axis=-1)
                pred_sar = np.argmax(
                    sar.cpu().detach().numpy(), axis=1)
                pred_sent = np.argmax(
                    sent.cpu().detach().numpy(), axis=1)
                pred_emo = np.argmax(
                    emo.cpu().detach().numpy(), axis=1)

                sar_f1 = f1_score(label_sar, pred_sar, average='micro')
                sent_f1 = f1_score(label_sent, pred_sent, average='micro')
                emo_f1 = f1_score(label_emo, pred_emo, average='micro')
                sar_acc = accuracy_score(
                    label_sar, pred_sar)
                sent_acc = accuracy_score(
                    label_sent, pred_sent)
                emo_acc = accuracy_score(
                    label_emo, pred_emo)
                logger.info(('train result sar-f1:%f sent-f1:%f ' +
                            'emo-f1:%f sar-acc:%f sent-acc:%f emo-acc:%f\n')
                            % (sar_f1, sent_f1, emo_f1,
                            sar_acc, sent_acc, emo_acc))
                evalResult = evaluate(model, bestResult, batchsize=32)
                if evalResult > bestResult:
                    torch.save(model.state_dict(), statePATH)
                    torch.save(model, modelPATH)
                    bestResult = evalResult

            loss.backward()
            # torch.cuda.empty_cache()
            optimizer.step()
            model.zero_grad()


def evaluate(model, bestResult, batchsize):
    valData = MustardDataset(datatye='dev')
    val_loader = DataLoader(
        valData,
        batch_size=batchsize,
        shuffle=True,
        pin_memory=True)
    model.eval()
    lossFun_val = nn.CrossEntropyLoss().cuda()
    with torch.no_grad():
        outputsar, outputsent, outputemo = [], [], []
        tarsar, tarsent, taremo = [], [], []
        for batch in val_loader:
            textInput = batch[0][0].cuda().to(torch.float32)
            imageInput = batch[0][1].cuda().to(torch.float32)
            tWavPath = batch[0][2].cuda().to(torch.float32)
            cWavPath = batch[0][3].cuda().to(torch.float32)
            sarLabel = batch[1][0].to(torch.float32).cuda()
            sentLabel = batch[1][1].to(torch.float32).cuda()
            emoLabel = batch[1][2].to(torch.float32).cuda()
            sar, sent, emo = \
                model(textInput, imageInput, tWavPath, cWavPath)

            sarArgmax = torch.argmax(sarLabel, dim=-1)
            sentArgmax = torch.argmax(sentLabel, dim=-1)
            emoArgmax = torch.argmax(emoLabel, dim=-1)
            loss1_val = lossFun_val(sar, sarArgmax)
            loss2_val = lossFun_val(sent, sentArgmax)
            loss3_val = lossFun_val(emo, emoArgmax)
            loss_val = (loss1_val + loss2_val + loss3_val)/3
            logger.info('val loss1:%f loss2:%f loss3:%f loss:%f\n'
                % (loss1_val.item(),
                    loss2_val.item(),
                    loss3_val.item(),
                    loss_val.item()))

            label_sar = np.argmax(
                sarLabel.cpu().detach().numpy(), axis=-1)
            label_sent = np.argmax(
                sentLabel.cpu().detach().numpy(), axis=-1)
            label_emo = np.argmax(
                emoLabel.cpu().detach().numpy(), axis=-1)
            pred_sar = np.argmax(
                sar.cpu().detach().numpy(), axis=1)
            pred_sent = np.argmax(
                sent.cpu().detach().numpy(), axis=1)
            pred_emo = np.argmax(
                emo.cpu().detach().numpy(), axis=1)
            outputsar.append(pred_sar)
            outputsent.append(pred_sent)
            outputemo.append(pred_emo)
            tarsar.append(label_sar)
            tarsent.append(label_sent)
            taremo.append(label_emo)

        outputsar = np.concatenate(
            np.array(outputsar, dtype=object))
        outputsent = np.concatenate(
            np.array(outputsent, dtype=object))
        outputemo = np.concatenate(
            np.array(outputemo, dtype=object))
        tarsar = np.concatenate(
            np.array(tarsar, dtype=object))
        tarsent = np.concatenate(
            np.array(tarsent, dtype=object))
        taremo = np.concatenate(
            np.array(taremo, dtype=object))

        # outputsar = np.concatenate(
        #     np.array(outputsar))
        # outputsent = np.concatenate(
        #     np.array(outputsent))
        # outputemo = np.concatenate(
        #     np.array(outputemo))
        # tarsar = np.concatenate(
        #     np.array(tarsar))
        # tarsent = np.concatenate(
        #     np.array(tarsent))
        # taremo = np.concatenate(
        #     np.array(taremo))
        print('tarsar:', tarsar)
        print('outputsar:', outputsar)
        print('tarsent:', tarsent)
        print('outputsent:', outputsent)
        print('taremo:', taremo)
        print('outputemo:', outputemo)
        sar_f1 = f1_score(
            tarsar, outputsar, average='micro')
        sent_f1 = f1_score(
            tarsent, outputsent, average='micro')
        emo_f1 = f1_score(
            taremo, outputemo, average='micro')
        sar_acc = accuracy_score(
            tarsar, outputsar)
        sent_acc = accuracy_score(
            tarsent, outputsent)
        emo_acc = accuracy_score(
            taremo, outputemo)
        logger.info(('val-result sar-f1:%f sent-f1:%f emo-f1:%f' +
                    ' sar-acc:%f sent-acc:%f emo-acc:%f\n')
                    % (sar_f1, sent_f1, emo_f1,
                    sar_acc, sent_acc, emo_acc))
        tmpResult = sar_acc + sent_acc + emo_acc
        if tmpResult > bestResult:
            bestResult = tmpResult
    return bestResult


def test(statePATH):
    testData = MustardDataset(datatye='test')
    batchsize = 48
    data_loader = DataLoader(
        testData,
        batch_size=batchsize,
        shuffle=True,
        pin_memory=True
        )
    model = M2Model(batchsize=batchsize).cuda()
    model.load_state_dict(
        torch.load(statePATH))
    model.eval()
    with torch.no_grad():
        outputsar, outputsent, outputemo = [], [], []
        tarsar, tarsent, taremo = [], [], []
        for batch in data_loader:
            textInput = batch[0][0].cuda().to(torch.float32)
            imageInput = batch[0][1].cuda().to(torch.float32)
            tWavPath = batch[0][2].cuda().to(torch.float32)
            cWavPath = batch[0][3].cuda().to(torch.float32)
            sarLabel = batch[1][0].to(torch.float32).cuda()
            sentLabel = batch[1][1].to(torch.float32).cuda()
            emoLabel = batch[1][2].to(torch.float32).cuda()
            sar, sent, emo = \
                model(textInput, imageInput, tWavPath, cWavPath)

            label_sar = np.argmax(
                sarLabel.cpu().detach().numpy(), axis=-1)
            label_sent = np.argmax(
                sentLabel.cpu().detach().numpy(), axis=-1)
            label_emo = np.argmax(
                emoLabel.cpu().detach().numpy(), axis=-1)
            pred_sar = np.argmax(
                sar.cpu().detach().numpy(), axis=1)
            pred_sent = np.argmax(
                sent.cpu().detach().numpy(), axis=1)
            pred_emo = np.argmax(
                emo.cpu().detach().numpy(), axis=1)
            outputsar.append(pred_sar)
            outputsent.append(pred_sent)
            outputemo.append(pred_emo)
            tarsar.append(label_sar)
            tarsent.append(label_sent)
            taremo.append(label_emo)

        outputsar = np.concatenate(
            np.array(outputsar, dtype=object))
        outputsent = np.concatenate(
            np.array(outputsent, dtype=object))
        outputemo = np.concatenate(
            np.array(outputemo, dtype=object))
        tarsar = np.concatenate(
            np.array(tarsar, dtype=object))
        tarsent = np.concatenate(
            np.array(tarsent, dtype=object))
        taremo = np.concatenate(
            np.array(taremo, dtype=object))

        # outputsar = np.concatenate(
        #     np.array(outputsar))
        # outputsent = np.concatenate(
        #     np.array(outputsent))
        # outputemo = np.concatenate(
        #     np.array(outputemo))
        # tarsar = np.concatenate(
        #     np.array(tarsar))
        # tarsent = np.concatenate(
        #     np.array(tarsent))
        # taremo = np.concatenate(
        #     np.array(taremo))

        sar_f1 = f1_score(
            tarsar, outputsar, average='micro')
        sent_f1 = f1_score(
            tarsent, outputsent, average='micro')
        emo_f1 = f1_score(
            taremo, outputemo, average='micro')
        sar_acc = accuracy_score(
            tarsar, outputsar)
        sent_acc = accuracy_score(
            tarsent, outputsent)
        emo_acc = accuracy_score(
            taremo, outputemo)
        print('test tarsar:', tarsar)
        print('test outputsar:', outputsar)
        print('test tarsent:', tarsent)
        print('test outputsent:', outputsent)
        print('test taremo:', taremo)
        print('test outputemo:', outputemo)
        logger.info(('test-result sar-f1:%f sent-f1:%f emo-f1:%f' +
                    'sar-acc:%f sent-acc:%f emo-acc:%f\n')
                    % (sar_f1, sent_f1, emo_f1,
                    sar_acc, sent_acc, emo_acc))


if __name__ == '__main__':
    logging.basicConfig(filemode='w')
    logger = logging.getLogger(__name__)
    logger.setLevel(level=logging.INFO)
    handler = logging.FileHandler(
        "../../log/m2modelTextBert_imageAudioFromFile.txt")
    handler.setLevel(logging.INFO)
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    logger.info("**********Start print log**********")

    statePATH = '../../State_dict/m2modelTextBert_textremovetext' +\
        '/best_textremovetext_state_dice.pt'
    train(batchsize=48, epoch=100)
    test(statePATH)
