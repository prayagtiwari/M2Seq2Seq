from posixpath import sep
from torchvggish.torchvggish.vggish_changeinput import VGGish
import numpy as np
import torch
import torch.nn as nn
import csv
from efficientnet_pytorch import EfficientNet
from PIL import Image
from torchvision import transforms
import os
import math
import pandas as pd


def readcsv(fileName):
    '''
    将所有对话的目标语句、上下文语句、讽刺标签、情感标签、情绪标签都集合到uttDict中
    目标语句和上下文语句都在utterance list中，以对话的时间顺序展开，最后是目标语句
    现在返回的utterance是所有的utt，最多的语句是12句，最少的语句是2句
    '''
    with open(fileName, 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        uttNameList = []
        # context = np.array()
        for i in reader:
            if i[0] != '':
                uttNameList.append(i[0])
        uttNameList = list(set(uttNameList))
        uttNameList.remove("KEY")
        uttDict = {}
        for name in uttNameList:
            uttDict[name] = {}
            uttDict[name]['utterance'] = []
            uttDict[name]['sarcasm-label'] = ''
            uttDict[name]['sentiment-label'] = ''
            uttDict[name]['emotion-label'] = ''
            uttDict[name]['utt-number'] = ''

    with open(fileName, 'r', encoding='utf-8') as f1:
        reader = csv.reader(f1)
        for item in reader:
            if item[0] == 'KEY' or item[0] == '':
                continue
            uttDict[item[0]]['sarcasm-label'] = item[4]
            uttDict[item[0]]['sentiment-label'] = item[5]
            uttDict[item[0]]['emotion-label'] = item[7]
            uttDict[item[0]]['utterance'].append(item[2])
            uttDict[item[0]]['utt-number'] = item[0]
    return uttDict, uttNameList


def processUttDict(uttDict):
    '''
    将生成的dict中的utterance的范围缩小到3 即两条上下文和一条目标语句
    如果对话语句不够的话在最前面补充一个空字符串
    如果对话语句多于3条的话，将多余的按照距离目标语句更远的上下文语句越先删除的顺序进行删除
    '''
    for key in uttDict.keys():
        lenUtt = len(uttDict[key]['utterance'])
        if lenUtt == 2:
            uttDict[key]['utterance'].insert(0, '')
            uttDict[key]['utterance'].insert(0, '')
        elif lenUtt > 4:
            uttDict[key]['utterance'] = uttDict[key]['utterance'][-4:]
        elif lenUtt == 3:
            uttDict[key]['utterance'].insert(0, '')
        else:
            continue
    # minLenUtt = min(len(uttDict[key]['utterance']) for key in uttDict.keys())
    # print('processUttDict-minLenUtt:', minLenUtt)
    return uttDict


def processData_mustard(datatye):
    if datatye == 'train':
        datafile = '../mustard-dataset-train.csv'  # 600
        length = 600
    elif datatye == 'dev':
        datafile = '../mustard-dataset-dev.csv'  # 40
        length = 40
    elif datatye == 'test':
        datafile = '../mustard-dataset-test.csv'  # 50
        length = 50
    uttDict, uttNameList = readcsv(datafile)
    uttDict = processUttDict(uttDict)
    uttList = list(uttDict.values())
    frameNumbers = 4
    avgPool = nn.AvgPool3d((270, 2, 2), stride=(43, 1, 1))
    avgPoolFlatten = nn.Flatten(start_dim=-2)
    effNetModel = EfficientNet.from_pretrained('efficientnet-b0')
    vggishModel = torch.hub.load('harritaylor/torchvggish', 'vggish')
    image_transform = transforms.Compose([
        transforms.Resize([480, 360]),
        transforms.ToTensor(),
        transforms.Normalize(mean=(0.5, 0.5, 0.5), std=(0.5, 0.5, 0.5))
    ])
    
    for index in range(length):
        uttName = uttList[index]['utt-number']
        print('uttName:', uttName)

        '''
        process the image feature
        '''
        framePath = "../mustard-frames/"+uttName
        frameFile = os.listdir(framePath)
        numFrames = len(frameFile)
        sampleSeq = np.linspace(1, numFrames, num=4)
        sampleSeq = [math.ceil(seq) for seq in sampleSeq]

        def generateFrameName(sampleSeq):
            result = []
            for seq in sampleSeq:
                if int(seq/100) > 0:
                    name = "00"+str(seq)+".jpg"
                elif int(seq/10) > 0:
                    name = "000"+str(seq)+".jpg"
                else:
                    name = "0000"+str(seq)+".jpg"
                result.append(name)
            return result

        frameNames = generateFrameName(sampleSeq)
        featureList = []
        for frame in frameNames:
            img = image_transform(
                Image.open(framePath+'/'+frame)).unsqueeze(0)
            featureList.append(img)
        featureList = torch.cat(featureList)
        with torch.no_grad():
            featureList = effNetModel.extract_features(featureList)
            featureList = avgPool(featureList)
            featureList = avgPoolFlatten(featureList)

        imageFeature = featureList.cpu().detach().numpy()
        # imageFeature.shape: (4, 24, 140)
        indices_or_sections = imageFeature.shape[0]
        # indices_or_sections: 4
        imageFeaList = np.split(imageFeature, indices_or_sections=indices_or_sections, axis=0)
        # imageFeaList (1, 24, 140)
        imageFeaList = [np.squeeze(item, axis=0) for item in imageFeaList]
        # imageFeaList 4*(24, 140)
        feaNumber = 0
        rootPath = "./imageFeature/"+datatye+"/"+uttName
        os.mkdir(rootPath)
        for item in imageFeaList:
            savePath = rootPath+"/"+str(feaNumber)
            print(savePath)
            np.savetxt(savePath, item, fmt="%f", delimiter=",") 
            feaNumber += 1
        '''
        process the image feature
        '''

        '''
        process the audio feature
        '''
        targetWavPath = '../mustard_wav/wav/target/' + uttName + '.wav'
        contextWavPath = '../mustard_wav/wav/context/' + uttName + '_c.wav'
        with torch.no_grad():
            targetWav = vggishModel.forward(targetWavPath)
            tShape = targetWav.shape
            if len(tShape) == 1:
                targetWav = torch.unsqueeze(targetWav, dim=0)
        with torch.no_grad():
            contextWav = vggishModel.forward(contextWavPath)
        # 处理为相同的形状
            tAudioFeature = torch.unsqueeze(
                torch.mean(targetWav, dim=0), dim=0)  # torch.Size([1, 128])
            '''
            把一个上下文音频特征去掉不能被3整除的部分，然后均等分为三份
            '''
            midShape = contextWav.shape[0]
            more = midShape % 3
            midShape -= more
            contextWav, _ = torch.split(contextWav, [midShape, more], dim=0)
            chunkList = torch.chunk(contextWav, chunks=3, dim=0)
            chunkList = [
                torch.unsqueeze(torch.mean(tmp, dim=0), dim=0)
                for tmp in chunkList
            ]
            cAudioFeature = torch.cat(chunkList, dim=0)
            cAudioFeature = torch.unsqueeze(cAudioFeature, dim=-2)
            tAudioFeature = torch.unsqueeze(tAudioFeature, dim=-2)
            tAudioFeature = np.squeeze(tAudioFeature.cpu().detach().numpy(), axis=1)
            cAudioFeature = np.squeeze(cAudioFeature.cpu().detach().numpy(), axis=1)
            print("./audioFeature/"+datatye+"/context/"+uttName)
            print("./audioFeature/"+datatye+"/target/"+uttName)
            np.savetxt("./audioFeature/"+datatye+"/context/"+uttName, cAudioFeature, fmt="%f", delimiter=",") 
            np.savetxt("./audioFeature/"+datatye+"/target/"+uttName, tAudioFeature, fmt="%f", delimiter=",") 
        '''
        process the audio feature
        '''
    return


def testLoad(imageName, taudioName, caudioName):
    image = np.load(imageName)
    print(image)
    taudio = np.load(taudioName)
    print(taudio)
    caudio = np.load(caudioName)
    print(caudio)
    return


if __name__ == "__main__":
    processData_mustard('train')
    # testLoad()


# class MustardDataset(Dataset):

#     def __init__(self, datatye):
#         super().__init__()
#         '''
#         albert 文本初始化部分
#         '''
#         if datatye == 'train':
#             datafile = 'mustard-dataset-train.csv'
#         elif datatye == 'dev':
#             datafile = 'mustard-dataset-dev.csv'
#         elif datatye == 'test':
#             datafile = 'mustard-dataset-test.csv'
#         uttDict, self.uttNameList = readcsv(datafile)
#         uttDict = processUttDict(uttDict)
#         self.uttList = list(uttDict.values())
#         '''
#         efficientnet 图像初始化部分
#         '''
#         self.frameNumbers = 4
#         # self.effNetModel = EfficientNet.from_pretrained('efficientnet-b0')
#         self.image_transform = transforms.Compose([
#             transforms.Resize([480, 360]),
#             transforms.ToTensor(),
#             transforms.Normalize(mean=(0.5, 0.5, 0.5), std=(0.5, 0.5, 0.5))
#         ])

#         def maxUttLen():
#             '''
#             寻找数据集中最长长度的文本
#             '''
#             maxlen = 0
#             for item in self.uttList:
#                 encoded_input = self.tokenizer(
#                     item['utterance'],
#                     return_tensors='pt',
#                     padding=True)
#                 output = self.albertModel(**encoded_input)
#                 shape2 = output[0].shape[1]
#                 if maxlen < shape2:
#                     maxlen = shape2
#             print(maxlen)
#         # maxUttLen()

#     def __getitem__(self, index):
#         '''
#         将所有句子的嵌入长度设置为64，长度不足的进行补充，长度过长的进行剪裁
#         '''
#         utts = self.uttList[index]['utterance']
#         encoded_input = self.tokenizer(
#             utts,
#             max_length=24,
#             truncation=True,
#             return_tensors='pt',
#             padding='max_length')
#         # (batchsize, 4, 64)
#         '''
#         对图像进行处理，读取帧文件夹下的帧的数量，抽取四个index，作为使用的图像的index
#         '''
#         uttName = self.uttList[index]['utt-number']
#         # print('uttName:', uttName)
#         framePath = "./mustard-frames/"+uttName
#         frameFile = os.listdir(framePath)
#         numFrames = len(frameFile)
#         sampleSeq = np.linspace(1, numFrames, num=4)
#         sampleSeq = [math.ceil(seq) for seq in sampleSeq]

#         def generateFrameName(sampleSeq):
#             result = []
#             for seq in sampleSeq:
#                 if int(seq/100) > 0:
#                     name = "00"+str(seq)+".jpg"
#                 elif int(seq/10) > 0:
#                     name = "000"+str(seq)+".jpg"
#                 else:
#                     name = "0000"+str(seq)+".jpg"
#                 result.append(name)
#             return result

#         frameNames = generateFrameName(sampleSeq)
#         featureList = []
#         for frame in frameNames:
#             img = self.image_transform(
#                 Image.open(framePath+'/'+frame)).unsqueeze(0)
#             featureList.append(img)
#         featureList = torch.cat(featureList)
#         # torch.Size([4, 3, 480, 360])

#         '''
#         对音频数据进行处理，处理音频使用的torchvggish，现在好像只能使用相对路径，不能读取数据再进行处理
#         '''
#         targetWavPath = './mustard_wav/wav/target/' + uttName + '.wav'
#         contextWavPath = './mustard_wav/wav/context/' + uttName + '_c.wav'
#         targetWavFea = vggish_input.wavfile_to_examples(targetWavPath)
#         contextWavFea = vggish_input.wavfile_to_examples(contextWavPath)
#         '''
#         对数据标签进行处理
#         '''
#         sarcasmStr = self.uttList[index]['sarcasm-label']
#         sentimentStr = self.uttList[index]['sentiment-label']
#         emotionStr = self.uttList[index]['emotion-label']
#         if 'True' == sarcasmStr:
#             sarcasmLabel = np.array([0, 1], dtype=np.int8)
#         else:
#             sarcasmLabel = np.array([1, 0], dtype=np.int8)

#         sentimentLabel = np.zeros(3, dtype=np.int8)
#         if -1 == int(sentimentStr):
#             sentimentLabel[0] = 1
#         elif 0 == int(sentimentStr):
#             sentimentLabel[1] = 1
#         else:
#             sentimentLabel[2] = 1
#         emotionLabel = np.zeros(9, dtype=np.int8)
#         emotionLabel[int(emotionStr.split(',')[0])-1] = 1
#         # print('targetWavFea.shape:', targetWavFea.shape)
#         return [encoded_input['input_ids'], featureList,
#                 targetWavFea, contextWavFea],\
#             [sarcasmLabel, sentimentLabel, emotionLabel]

#     def __len__(self):
#         return len(self.uttList)

