import torch
# from torch import nn
from torch.utils.data import Dataset
from transformers import AlbertTokenizer, AlbertConfig
import numpy as np
import csv
# from efficientnet_pytorch import EfficientNet
# from PIL import Image
# from torchvision import transforms
import os
import math
# import torchvggish.torchvggish.vggish_input as vggish_input

'''
mustard数据集结构
KEY,SPEAKER,SENTENCE,SHOW,SARCASM,SENTIMENT_IMPLICIT,SENTIMENT_EXPLICIT,EMOTION_IMPLICIT,EMOTION_EXPLICIT
要使用的是 0-key 2-sentence 4-sarcasm 5-sent-im 7-emo-im
'''


def readcsv(fileName):
    '''
    将所有对话的目标语句、上下文语句、讽刺标签、情感标签、情绪标签都集合到uttDict中
    目标语句和上下文语句都在utterance list中，以对话的时间顺序展开，最后是目标语句
    现在返回的utterance是所有的utt，最多的语句是12句，最少的语句是2句
    '''
    with open(fileName, 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        uttNameList = []
        # context = np.array()
        for i in reader:
            if i[0] != '':
                uttNameList.append(i[0])
        uttNameList = list(set(uttNameList))
        uttNameList.remove("KEY")
        uttDict = {}
        for name in uttNameList:
            uttDict[name] = {}
            uttDict[name]['utterance'] = []
            uttDict[name]['sarcasm-label'] = ''
            uttDict[name]['sentiment-label'] = ''
            uttDict[name]['emotion-label'] = ''
            uttDict[name]['utt-number'] = ''

    with open(fileName, 'r', encoding='utf-8') as f1:
        reader = csv.reader(f1)
        for item in reader:
            if item[0] == 'KEY' or item[0] == '':
                continue
            uttDict[item[0]]['sarcasm-label'] = item[4]
            uttDict[item[0]]['sentiment-label'] = item[5]
            uttDict[item[0]]['emotion-label'] = item[7]
            uttDict[item[0]]['utterance'].append(item[2])
            uttDict[item[0]]['utt-number'] = item[0]
    return uttDict, uttNameList


def processUttDict(uttDict):
    '''
    将生成的dict中的utterance的范围缩小到3 即两条上下文和一条目标语句
    如果对话语句不够的话在最前面补充一个空字符串
    如果对话语句多于3条的话，将多余的按照距离目标语句更远的上下文语句越先删除的顺序进行删除
    '''
    for key in uttDict.keys():
        lenUtt = len(uttDict[key]['utterance'])
        if lenUtt == 2:
            uttDict[key]['utterance'].insert(0, '')
            uttDict[key]['utterance'].insert(0, '')
        elif lenUtt > 4:
            uttDict[key]['utterance'] = uttDict[key]['utterance'][-4:]
        elif lenUtt == 3:
            uttDict[key]['utterance'].insert(0, '')
        else:
            continue
    # minLenUtt = min(len(uttDict[key]['utterance']) for key in uttDict.keys())
    # print('processUttDict-minLenUtt:', minLenUtt)
    return uttDict


class MustardDataset(Dataset):

    def __init__(self, datatye):
        super().__init__()
        '''
        albert 文本初始化部分
        '''
        self.datatye = datatye
        if self.datatye == 'train':
            datafile = 'mustard-dataset-train.csv'
        elif self.datatye == 'dev':
            datafile = 'mustard-dataset-dev.csv'
        elif self.datatye == 'test':
            datafile = 'mustard-dataset-test.csv'
        uttDict, self.uttNameList = readcsv(datafile)
        uttDict = processUttDict(uttDict)
        self.uttList = list(uttDict.values())

        self.frameNumbers = 4

    def __getitem__(self, index):
        uttName = self.uttList[index]['utt-number']
        '''
        从文件夹中读取文本特征数据
        '''
        textPath = \
            "../mustard_data/textFeature/"+self.datatye+"/"+uttName+"/"
        textFea = [np.loadtxt(
                        textPath+str(num),
                        dtype=float,
                        delimiter=",") for num in range(4)]
        textFea = [np.expand_dims(item, axis=0) for item in textFea]
        textFea = np.concatenate(textFea, axis=0)
        textFea = torch.tensor(textFea)
        '''
        从文件夹中读取文本特征数据
        '''

        # (batchsize, 4, 64)
        '''
        对图像进行处理，读取帧文件夹下的帧的数量，抽取四个index，作为使用的图像的index
        '''
        # print('uttName:', uttName)
        audioPath = "../mustard_data/audioFeature/"+self.datatye+"/"
        imagePath = \
            "../mustard_data/imageFeature/"+self.datatye+"/"+uttName+"/"
        imageFea = [np.loadtxt(
                        imagePath+str(num),
                        dtype=float,
                        delimiter=",") for num in range(4)]
        imageFea = [np.expand_dims(item, axis=0) for item in imageFea]
        imageFea = np.concatenate(imageFea, axis=0)
        imageFea = torch.tensor(imageFea)
        # torch.Size([4, 3, 480, 360])

        '''
        对音频数据进行处理，处理音频使用的torchvggish，现在好像只能使用相对路径，不能读取数据再进行处理
        '''
        tAudioFea = audioPath+"target/"+uttName
        cAudioFea = audioPath+"context/"+uttName
        tAudioFea = np.expand_dims(
                        np.loadtxt(\
                            tAudioFea, \
                            dtype=float, \
                            delimiter=","), axis=0)
        tAudioFea = np.expand_dims(tAudioFea, axis=1)
        cAudioFea = np.loadtxt(
                        cAudioFea,
                        dtype=float,
                        delimiter=",")
        cAudioFea = np.expand_dims(cAudioFea, axis=1)
        tAudioFea = torch.tensor(tAudioFea)
        cAudioFea = torch.tensor(cAudioFea)
        '''
        对数据标签进行处理
        '''
        sarcasmStr = self.uttList[index]['sarcasm-label']
        sentimentStr = self.uttList[index]['sentiment-label']
        emotionStr = self.uttList[index]['emotion-label']
        if 'True' == sarcasmStr:
            sarcasmLabel = np.array([0, 1], dtype=np.int8)
        else:
            sarcasmLabel = np.array([1, 0], dtype=np.int8)

        sentimentLabel = np.zeros(3, dtype=np.int8)
        if -1 == int(sentimentStr):
            sentimentLabel[0] = 1
        elif 0 == int(sentimentStr):
            sentimentLabel[1] = 1
        else:
            sentimentLabel[2] = 1
        emotionLabel = np.zeros(9, dtype=np.int8)
        emotionLabel[int(emotionStr.split(',')[0])-1] = 1
        # print('targetWavFea.shape:', targetWavFea.shape)
        return [textFea, imageFea,
                tAudioFea, cAudioFea],\
            [sarcasmLabel, sentimentLabel, emotionLabel]

    def __len__(self):
        return len(self.uttList)


class MemotionDataset(Dataset):

    def __init__(self):
        super().__init__()
        self.textDataset = 'memotion-dataset.csv'
        imageDir =\
            '../memotion-7k-image-process/memotion_dataset_7k/imgdataset2'
        self.imageNameList = os.listdir(imageDir)

        def generateDataDict():
            uttDict = {}
            with open(self.textDataset, 'r', encoding='utf-8') as f:
                reader = csv.reader(f)
                a = 0
                for line in reader:
                    if line[0] == 'number':
                        continue
                    if line[1].split('.')[0] in self.imageNameList:
                        uttDict[line[0]] = {}
                        uttDict[line[0]]['utterence'] = line[3]
                        uttDict[line[0]]['imageName'] = line[1]
                        uttDict[line[0]]['sarcasm-label'] = line[5]
                        uttDict[line[0]]['sentiment-label'] = line[5]
                        uttDict[line[0]]['emotion-label'] = line[5]
                print(a)
        generateDataDict()

    def __getitem__(self, index):
        return 1


if __name__ == "__main__":
    # data_train = MustardDataset(datatye='dev')
    # sarList = []
    # sentList = []
    # emoList = []
    # for a in range(5):
    #     [output1, output2], \
    #         [sarcasmLabel, sentimentLabel, emotionLabel] = data_train[a]
    #     print(output1.shape)
    data_train = MustardDataset('train')
    a = 0
    for item in data_train:
        a += 1
        # data_train[i]
        print(a)
