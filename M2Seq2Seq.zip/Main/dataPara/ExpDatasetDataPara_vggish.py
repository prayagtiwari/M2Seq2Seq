import torch
# from torch import nn
from torch.utils.data import Dataset
from transformers import AlbertTokenizer, AlbertConfig
import numpy as np
import csv
from efficientnet_pytorch import EfficientNet
from PIL import Image
from torchvision import transforms
import os
import math


'''
mustard数据集结构
KEY,SPEAKER,SENTENCE,SHOW,SARCASM,SENTIMENT_IMPLICIT,SENTIMENT_EXPLICIT,EMOTION_IMPLICIT,EMOTION_EXPLICIT
要使用的是 0-key 2-sentence 4-sarcasm 5-sent-im 7-emo-im
'''


def readcsv(fileName):
    '''
    将所有对话的目标语句、上下文语句、讽刺标签、情感标签、情绪标签都集合到uttDict中
    目标语句和上下文语句都在utterance list中，以对话的时间顺序展开，最后是目标语句
    现在返回的utterance是所有的utt，最多的语句是12句，最少的语句是2句
    '''
    with open(fileName, 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        uttNameList = []
        # context = np.array()
        for i in reader:
            if i[0] != '':
                uttNameList.append(i[0])
        uttNameList = list(set(uttNameList))
        uttNameList.remove("KEY")
        uttDict = {}
        for name in uttNameList:
            uttDict[name] = {}
            uttDict[name]['utterance'] = []
            uttDict[name]['sarcasm-label'] = ''
            uttDict[name]['sentiment-label'] = ''
            uttDict[name]['emotion-label'] = ''
            uttDict[name]['utt-number'] = ''

    with open(fileName, 'r', encoding='utf-8') as f1:
        reader = csv.reader(f1)
        for item in reader:
            if item[0] == 'KEY' or item[0] == '':
                continue
            uttDict[item[0]]['sarcasm-label'] = item[4]
            uttDict[item[0]]['sentiment-label'] = item[5]
            uttDict[item[0]]['emotion-label'] = item[7]
            uttDict[item[0]]['utterance'].append(item[2])
            uttDict[item[0]]['utt-number'] = item[0]
    return uttDict, uttNameList


def processUttDict(uttDict):
    '''
    将生成的dict中的utterance的范围缩小到3 即两条上下文和一条目标语句
    如果对话语句不够的话在最前面补充一个空字符串
    如果对话语句多于3条的话，将多余的按照距离目标语句更远的上下文语句越先删除的顺序进行删除
    '''
    for key in uttDict.keys():
        lenUtt = len(uttDict[key]['utterance'])
        if lenUtt == 2:
            uttDict[key]['utterance'].insert(0, '')
            uttDict[key]['utterance'].insert(0, '')
        elif lenUtt > 4:
            uttDict[key]['utterance'] = uttDict[key]['utterance'][-4:]
        elif lenUtt == 3:
            uttDict[key]['utterance'].insert(0, '')
        else:
            continue
    # minLenUtt = min(len(uttDict[key]['utterance']) for key in uttDict.keys())
    # print('processUttDict-minLenUtt:', minLenUtt)
    return uttDict


class MustardDataset(Dataset):

    def __init__(self, datatye):
        super().__init__()
        '''
        albert 文本初始化部分
        '''
        if datatye == 'train':
            datafile = 'mustard-dataset-train.csv'
        elif datatye == 'dev':
            datafile = 'mustard-dataset-dev.csv'
        elif datatye == 'test':
            datafile = 'mustard-dataset-test.csv'
        pretrained = './albert-base-v2'
        self.tokenizer = AlbertTokenizer.from_pretrained(pretrained)
        # self.albertModel = AlbertModel.from_pretrained(pretrained)
        self.config = AlbertConfig.from_pretrained(pretrained)
        uttDict, self.uttNameList = readcsv(datafile)
        uttDict = processUttDict(uttDict)
        self.uttList = list(uttDict.values())
        '''
        efficientnet 图像初始化部分
        '''
        self.frameNumbers = 4
        self.effNetModel = EfficientNet.from_pretrained('efficientnet-b0')
        self.image_transform = transforms.Compose([
            transforms.Resize([480, 360]),
            transforms.ToTensor(),
            transforms.Normalize(mean=(0.5, 0.5, 0.5), std=(0.5, 0.5, 0.5))
        ])

        '''
        vggish 模型加载
        '''
        self.vggishModel = torch.hub.load('harritaylor/torchvggish', 'vggish')

        def maxUttLen():
            '''
            寻找数据集中最长长度的文本
            '''
            maxlen = 0
            for item in self.uttList:
                encoded_input = self.tokenizer(
                    item['utterance'],
                    return_tensors='pt',
                    padding=True)
                output = self.albertModel(**encoded_input)
                shape2 = output[0].shape[1]
                if maxlen < shape2:
                    maxlen = shape2
            print(maxlen)
        # maxUttLen()

    def __getitem__(self, index):
        '''
        将所有句子的嵌入长度设置为64，长度不足的进行补充，长度过长的进行剪裁
        '''
        utts = self.uttList[index]['utterance']
        encoded_input = self.tokenizer(
            utts,
            max_length=64,
            truncation=True,
            return_tensors='pt',
            padding='max_length')
        # (batchsize, 4, 64)
        '''
        对图像进行处理，读取帧文件夹下的帧的数量，抽取四个index，作为使用的图像的index
        '''
        uttName = self.uttList[index]['utt-number']
        # print('uttName:', uttName)
        framePath = "./mustard-frames/"+uttName
        frameFile = os.listdir(framePath)
        numFrames = len(frameFile)
        sampleSeq = np.linspace(1, numFrames, num=4)
        sampleSeq = [math.ceil(seq) for seq in sampleSeq]

        def generateFrameName(sampleSeq):
            result = []
            for seq in sampleSeq:
                if int(seq/100) > 0:
                    name = "00"+str(seq)+".jpg"
                elif int(seq/10) > 0:
                    name = "000"+str(seq)+".jpg"
                else:
                    name = "0000"+str(seq)+".jpg"
                result.append(name)
            return result

        frameNames = generateFrameName(sampleSeq)
        featureList = []
        for frame in frameNames:
            img = self.image_transform(
                Image.open(framePath+'/'+frame)).unsqueeze(0)
            featureList.append(img)
        featureList = torch.cat(featureList)
        # torch.Size([4, 3, 480, 360])

        '''
        对音频数据进行处理，处理音频使用的torchvggish，现在好像只能使用相对路径，不能读取数据再进行处理
        '''
        targetWavPath = './mustard_wav/wav/target/' + uttName + '.wav'
        contextWavPath = './mustard_wav/wav/context/' + uttName + '_c.wav'
        with torch.no_grad():
            targetWav = self.vggishModel.forward(targetWavPath)
        tShape = targetWav.shape
        if len(tShape) == 1:
            targetWav = torch.unsqueeze(targetWav, dim=0)
        with torch.no_grad():
            contextWav = self.vggishModel.forward(contextWavPath)
        # 处理为相同的形状
        tAudioFeature = torch.unsqueeze(
            torch.mean(targetWav, dim=0), dim=0)  # torch.Size([1, 128])
        '''
        把一个上下文音频特征去掉不能被3整除的部分，然后均等分为三份
        '''
        midShape = contextWav.shape[0]
        more = midShape % 3
        midShape -= more
        contextWav, _ = torch.split(contextWav, [midShape, more], dim=0)
        chunkList = torch.chunk(contextWav, chunks=3, dim=0)
        chunkList = [
            torch.unsqueeze(torch.mean(tmp, dim=0), dim=0)
            for tmp in chunkList
        ]
        cAudioFeature = torch.cat(chunkList, dim=0)
        cAudioFeature = torch.unsqueeze(cAudioFeature, dim=-2)
        tAudioFeature = torch.unsqueeze(tAudioFeature, dim=-2)
        # tAudioFeature torch.Size([1, 128])
        # cAudioFeature torch.Size([3, 128])
        '''
        对数据标签进行处理
        '''
        sarcasmStr = self.uttList[index]['sarcasm-label']
        sentimentStr = self.uttList[index]['sentiment-label']
        emotionStr = self.uttList[index]['emotion-label']
        if 'True' == sarcasmStr:
            sarcasmLabel = np.array([0, 1], dtype=np.int8)
        else:
            sarcasmLabel = np.array([1, 0], dtype=np.int8)

        sentimentLabel = np.zeros(3, dtype=np.int8)
        if -1 == int(sentimentStr):
            sentimentLabel[0] = 1
        elif 0 == int(sentimentStr):
            sentimentLabel[1] = 1
        else:
            sentimentLabel[2] = 1
        emotionLabel = np.zeros(9, dtype=np.int8)
        emotionLabel[int(emotionStr.split(',')[0])-1] = 1

        return [encoded_input['input_ids'], featureList,
                tAudioFeature, cAudioFeature],\
            [sarcasmLabel, sentimentLabel, emotionLabel]

    def __len__(self):
        return len(self.uttList)


class MemotionDataset(Dataset):

    def __init__(self):
        super().__init__()
        self.textDataset = 'memotion-dataset.csv'
        imageDir =\
            '../memotion-7k-image-process/memotion_dataset_7k/imgdataset2'
        self.imageNameList = os.listdir(imageDir)

        def generateDataDict():
            uttDict = {}
            with open(self.textDataset, 'r', encoding='utf-8') as f:
                reader = csv.reader(f)
                a = 0
                for line in reader:
                    if line[0] == 'number':
                        continue
                    if line[1].split('.')[0] in self.imageNameList:
                        uttDict[line[0]] = {}
                        uttDict[line[0]]['utterence'] = line[3]
                        uttDict[line[0]]['imageName'] = line[1]
                        uttDict[line[0]]['sarcasm-label'] = line[5]
                        uttDict[line[0]]['sentiment-label'] = line[5]
                        uttDict[line[0]]['emotion-label'] = line[5]
                print(a)
        generateDataDict()

    def __getitem__(self, index):
        return 1


if __name__ == "__main__":
    # data_train = MustardDataset(datatye='dev')
    # sarList = []
    # sentList = []
    # emoList = []
    # for a in range(5):
    #     [output1, output2], \
    #         [sarcasmLabel, sentimentLabel, emotionLabel] = data_train[a]
    #     print(output1.shape)
    data_train = MustardDataset('train')
    a = 0
    for i in range(10):
        a += 1
        data_train[i]
        print()
