# from torch.nn.modules import activation
from ExpDatasetTextBert import MustardDataset
import torch.nn.functional as F
import torch
from torch import nn
from torch.nn import Module
from torch.nn import Dropout, Flatten, Linear,\
    Softmax, GRU, AvgPool3d, MultiheadAttention
from torch.utils.data import DataLoader
from transformers import AlbertModel, AlbertConfig
from efficientnet_pytorch import EfficientNet
import numpy as np

# num_gpus = torch.cuda.device_count()
# device = torch.device('cuda' if num_gpus > 0 else 'cpu')
# device = torch.device('cuda:0 1')
# print(device)


class M2Model(Module):
    def __init__(self):
        super(M2Model, self).__init__()
        # pretrained = './albert-base-v2'
        self.albertModel = AlbertModel.from_pretrained('./albert-base-v2')
        self.config = AlbertConfig.from_pretrained('./albert-base-v2')

        self.effNetModel = EfficientNet.from_pretrained('efficientnet-b0')
        self.vggishModel = torch.hub.load('harritaylor/torchvggish', 'vggish')
        self.vggLinear = Linear(in_features=1, out_features=64, bias=True)
        '''
        torch.Size([batchsize, 4, 1280, 15, 11])
        通过efficientnet网络提取的特征的形状

        return：一个（batchsize, 4, 1280, 2, 2）的tensor
        通过对最后两维进行flatten
        结果尺寸 torch.Size([256, 4, 1280, 4]) 256-batchsize
        期望尺寸 （batchsize, 4, 1280， 4）
        self.avgPool = AvgPool3d((1, 14, 10), stride=(1, 1, 1))
        此时的结果是（batchsize, 4, 1280, 2, 2）
        '''
        self.avgPool = AvgPool3d((270, 2, 2), stride=(16, 1, 1))
        '''
        self.avgPool 和 self.avgPoolFlatten 用法：

        m3d = nn.AvgPool3d((1, 2, 2), stride=(1, 1, 1))
        input = torch.randn(256, 4, 1280, 15, 11)
        output3d = m3d(input)
        flattenlayer = nn.Flatten(start_dim=-2)
        output3d = flattenlayer(output3d)---(256, 4, 1280, 140)
        '''
        # 此时的结果是（batchsize, 4, 1280, 14, 10）-（batchsize, 4, 64, 140）
        self.avgPoolFlatten = nn.Flatten(start_dim=-2)
        '''
        input_size hidden_size number_layers bidirectional
        将文本和经过池化的图像向量输入到两个bigru中，获取隐藏层的状态，用于注意力机制
        text input - (batchsize, 4, 64, 768)
        image input - (batchsize, 4, 1280, 4)
        '''
        '''
        self.textBiGRU 和 self.imageBiGRU 用法：

        textInput = torch.randn(111, 4, 64, 768)
        textBiGRU = nn.GRU(
            input_size=768,
            hidden_size=256,
            num_layers=1,
            batch_first=True,
            bidirectional=True)
        textChunks = torch.chunk(textInput, 4, 1)
        for tchunk in textChunks:
            tchunk = torch.squeeze(tchunk) --- (111, 64, 768)
            tchunk, h0 = textBiGRU(tchunk)
            --- tchunk-([111, 64, 512]) h0-([2, 111, 256])

        需要用到的输出 tchunk-([111, 64, 512])
        (batchsize, seqLen, directionNumber*hiddensize)
        '''
        # encoderGRU
        # gruHiddenSize = 256
        # gruDirectionNumber = 2
        self.textBiGRU = GRU(
            input_size=768,
            hidden_size=256,
            num_layers=1,
            batch_first=True,
            bidirectional=True)

        self.imageBiGRU = GRU(
            input_size=140,
            hidden_size=256,
            num_layers=1,
            batch_first=True,
            bidirectional=True)

        self.audioBiGRU = GRU(
            input_size=128,
            hidden_size=256,
            num_layers=1,
            batch_first=True,
            bidirectional=True)
        # encoderGRU
        '''
        attention的输入：
        文本-(64, 111, 512)
        -(seqLen, batchsize, gruHiddenSize*gruDirectionNumber)
        图像-(1280, 111, 512)
        -(featureLayer, batchsize, gruHiddenSize*gruDirectionNumber)

        要得到上面形状的输入，需要使用torch.transpose(input, dim_0=0, dim_1=1)
        来将batchsize维和seq（featurlayer）维进行交换

        output:
        query = torch.rand(111, 64, 512)
        query = torch.transpose(query, dim0=0, dim1=1)
        key = torch.rand(64, 111, 512)
        value = torch.rand(64, 111, 512)
        attn_output, attn_output_weights = multihead_attn(query, key, value)
        attn_output -- ([64, 111, 512])
        attn_output_weights -- ([111, 64, 64])

        要找到att合适的用于后续的输出
        '''
        # intra inter modal component
        # embedDim = gruHiddenSize * gruDirectionNumber
        # numberHead = 1
        # interAttNumberHead = 4
        # interAttEmbedDim = 512

        self.textEncodeAtt = MultiheadAttention(512, 1)
        self.imageEncodeAtt = MultiheadAttention(512, 1)
        self.audioEncodeAtt = MultiheadAttention(512, 1)

        self.targetWeight = nn.Parameter(torch.Tensor([0.5]))
        self.contextWeight = nn.Parameter(torch.Tensor([0.5]))

        self.interTtoI = MultiheadAttention(
            512, 4)
        self.interItoT = MultiheadAttention(
            512, 4)
        self.interTtoA = MultiheadAttention(
            512, 4)
        self.interAtoT = MultiheadAttention(
            512, 4)
        self.interAtoI = MultiheadAttention(
            512, 4)
        self.interItoA = MultiheadAttention(
            512, 4)
        # intra inter modal component

        # decoder
        # deInputSize = 512
        # deHiddenSize = 512
        self.sentimentGRU = GRU(
            input_size=512,
            hidden_size=512,
            num_layers=1,
            batch_first=False)
        self.emotionGRU = GRU(
            input_size=512,
            hidden_size=512,
            num_layers=1,
            batch_first=False)
        self.sarcasmGRU = GRU(
            input_size=512,
            hidden_size=512,
            num_layers=1,
            batch_first=False)
        self.sentimentAtt = MultiheadAttention(512, 1)
        self.emotionAtt = MultiheadAttention(512, 1)
        self.sarcasmAtt = MultiheadAttention(512, 1)
        self.sarSoftmax = nn.Softmax(dim=1)
        self.sentSoftmax = nn.Softmax(dim=1)
        self.emoSoftmax = nn.Softmax(dim=1)
        # sentSeqLen = 128
        # modalCount = 3
        # sentInFeature = deHiddenSize*sentSeqLen*modalCount
        # sentInFeature = 196608
        # scaleShape = 512
        self.sentimentDense = nn.Linear(
            in_features=512, out_features=3)
        self.sentScaleDense = nn.Linear(
            in_features=196608, out_features=512)
        # emoSeqLen = 128+1+1
        # emoInFeature = deHiddenSize*emoSeqLen+sentInFeature*modalCount
        # emoInFeature = 394240
        self.emotionDense = nn.Linear(
            in_features=512, out_features=9)
        self.emoScaleDense = nn.Linear(
            in_features=394240, out_features=512)
        # sarSeqLen = 128+1+1
        # sarInFeature = 264192*modalCount
        # deHiddenSize*sarSeqLen+emoInFeature
        # sarInFeature = 788480
        self.sarcasmDense = nn.Linear(
            in_features=512, out_features=2)
        self.sarScaleDense = nn.Linear(
            in_features=788480, out_features=512)
        # self.scaleDense = nn.Linear(in_features=1024, out_features=64)
        # decoder

    def forward(self, text, image, tWavPath, cWavPath):
        '''
        input text bert预训练模型生成的四个句子的词向量集合 （batchsize，4, 64，768）
        input image efficientnet预训练模型生成的四个图像的特征集合 （batchsize， 4， 1280， 15， 11）
        '''
        batchsize = text.shape[0]
        contextsize = text.shape[1]
        # bert
        textChunks = torch.chunk(text, contextsize, 1)
        text = [
            self.albertModel(torch.squeeze(item))[0] for item in textChunks]
        text = [
            torch.unsqueeze(item, dim=1) for item in text]
        text = torch.cat(text, dim=1)
        # torch.Size([2, 4, 64, 768])
        # bert

        # efficient-net
        imageChunks = torch.chunk(image, batchsize, 0)
        # torch.Size([2, 1, 3, 480, 360])
        imageChunks = [
            torch.squeeze(item) for item in imageChunks]
        imageBatch = [
            self.effNetModel.extract_features(chunk) for chunk in imageChunks]
        # torch.Size([4, 1280, 15, 11])
        imageBatch = torch.cat([
            torch.unsqueeze(item, 0) for item in imageBatch
        ], dim=0)
        # torch.Size([2, 4, 1280, 15, 11]) 2-batchsize
        # efficient-net

        # vggish
        tAudioFeature, cAudioFeature = [], []
        for item in tWavPath:
            temp = self.vggishModel.forward(item)
            tShape = temp.shape
            if len(tShape) == 1:
                temp = torch.unsqueeze(temp, dim=0)
            tAudioFeature.append(temp)
        for item in cWavPath:
            temp = self.vggishModel.forward(item)
            cAudioFeature.append(temp)

        tAudioFeature = [
            torch.unsqueeze(item, 0) for item in tAudioFeature]
        cAudioFeature = [
            torch.unsqueeze(item, 0) for item in cAudioFeature]

        tAudioFeature = [
            torch.unsqueeze(torch.mean(item, dim=1), dim=0)
            for item in tAudioFeature]
        tmpCAFeature = []
        '''
        把一个上下文音频特征去掉不能被3整除的部分，然后均等分为三份
        '''
        for item in cAudioFeature:
            midShape = item.shape[1]
            more = midShape % 3
            midShape -= more
            item, _ = torch.split(item, [midShape, more], dim=1)
            chunkList = torch.chunk(item, chunks=3, dim=1)
            chunkList = [
                torch.unsqueeze(torch.mean(tmp, dim=1), dim=0)
                for tmp in chunkList
            ]
            tmpCAFeature.append(torch.cat(chunkList, dim=1))
        tAudioFeature = torch.cat(tAudioFeature, 0)  # torch.Size([2, 1, 128])
        tAudioFeature = torch.unsqueeze(tAudioFeature, dim=-1)
        cAudioFeature = torch.cat(tmpCAFeature, 0)  # torch.Size([2, 3, 128])
        cAudioFeature = torch.unsqueeze(cAudioFeature, dim=-1)
        tAudioFeature = self.vggLinear(tAudioFeature)
        cAudioFeature = self.vggLinear(cAudioFeature)
        tAudioFeature = torch.transpose(tAudioFeature, dim0=-1, dim1=-2)
        cAudioFeature = torch.transpose(cAudioFeature, dim0=-1, dim1=-2)
        audio = torch.cat([tAudioFeature, cAudioFeature], dim=1)
        # torch.Size([2, 4, 64, 128])
        # print('tAudioFeature.shape:', tAudioFeature.shape)
        # print('cAudioFeature.shape:', cAudioFeature.shape)
        # print('audio.shape:', audio.shape)
        # vggish

        image = self.avgPool(imageBatch)
        image = self.avgPoolFlatten(image)
        # torch.Size([2, 4, 64, 140])

        textChunks = torch.chunk(text, contextsize, 1)
        imageChunks = torch.chunk(image, contextsize, 1)
        audioChunks = torch.chunk(audio, contextsize, 1)
        tChunkList = []
        iChunkList = []
        aChunkList = []
        thnList = []
        ihnList = []
        ahnList = []
        tEncoderAttWeight = []
        iEncoderAttWeight = []
        aEncoderAttWeight = []

        # multi-modal encoder
        for tChunk in textChunks:
            '''
            文本的使用gru学习关联关系的部分
            '''
            # torch.Size([2, 64, 768])
            tChunk = torch.squeeze(tChunk, dim=1)
            # tChunk -- torch.Size([2, 64, 512])
            tChunk, thn = self.textBiGRU(tChunk)
            thnList.append(thn)
            '''
            文本的使用attention学习最后的句子表示的encoder部分
            '''
            query = torch.transpose(tChunk, dim0=0, dim1=1)
            key = torch.transpose(tChunk, dim0=0, dim1=1)
            value = torch.transpose(tChunk, dim0=0, dim1=1)
            # textAttnOutput -- torch.Size([64, 2, 512])
            textAttnOutput, textAttnOutputWeights = \
                self.textEncodeAtt(query, key, value)
            tChunkList.append(textAttnOutput)
            tEncoderAttWeight.append(textAttnOutputWeights)

        for iChunk in imageChunks:
            '''
            图像的使用gru学习关联关系的部分
            '''
            # torch.Size([2, 64, 140])
            iChunk = torch.squeeze(iChunk, dim=1)
            # torch.Size([2, 64, 512])
            iChunk, ihn = self.imageBiGRU(iChunk)
            ihnList.append(ihn)
            '''
            图像的使用attention学习最后的句子表示的encoder部分
            '''
            query = torch.transpose(iChunk, dim0=0, dim1=1)
            key = torch.transpose(iChunk, dim0=0, dim1=1)
            value = torch.transpose(iChunk, dim0=0, dim1=1)
            # imageAttnOutput -- torch.Size([64, 2, 512])
            imageAttnOutput, imageAttnOutputWeights = \
                self.imageEncodeAtt(query, key, value)
            iChunkList.append(imageAttnOutput)
            # 对求得的一个句子的表示求平均值，得到表示一个句子的向量表示（64,batchsize,512）->(batchsize,1,512)
            iEncoderAttWeight.append(imageAttnOutputWeights)

        for aChunk in audioChunks:
            aChunk = torch.squeeze(aChunk, dim=1)
            aChunk, ahn = self.audioBiGRU(aChunk)
            ahnList.append(ahn)
            query = torch.transpose(aChunk, dim0=0, dim1=1)
            key = torch.transpose(aChunk, dim0=0, dim1=1)
            value = torch.transpose(aChunk, dim0=0, dim1=1)
            audioAttnOutput, audioAttnOutputWeights = \
                self.audioEncodeAtt(query, key, value)
            aChunkList.append(audioAttnOutput)
            aEncoderAttWeight.append(audioAttnOutputWeights)
            # aChunk.shape: torch.Size([2, 64, 512])
            # audioAttnOutput.shape: torch.Size([64, 2, 512])
            # audioAttnOutputWeights.shape: torch.Size([2, 64, 64])
        # multi-modal encoder
        # intra-modal attention mechanism
        # 对求出的目标语句和上下文语句进行 拼接式注意力机制 得出表示一个对话的表示
        # 这里的注意力机制是将目标语句和上下文语句分别拼接hi（i 1-3）起来求和sum
        # 在分别求每个上下文语句的 hi/sum 作为权重然后再进行加权和
        targetText = tChunkList[-1]
        targetImage = iChunkList[-1]
        targetAudio = aChunkList[-1]

        '''
        text
        '''
        # tConAtt[0] -- torch.Size([64, 2, 512])
        tConAtt = [torch.exp(
            torch.tanh(targetText+tContext))
            for tContext in tChunkList[:-1]
        ]
        # tConAttSum -- torch.Size([64, 2, 512])
        tConAttSum = tConAtt[0] + tConAtt[1] + tConAtt[2]
        # tIntraAttOutput0[0] -- torch.Size([64, 2, 512])
        tIntraAttOutput = [
            (tConAtt[i]/tConAttSum)*tChunkList[i] for i in range(3)
        ]
        # tIntraAttOutput1[0] -- torch.Size([64, 2, 512])
        tIntraAttOutput = tIntraAttOutput[0] +\
            tIntraAttOutput[1]+tIntraAttOutput[2]
        # tIntraAttOutput2 -- torch.Size([64, 2, 512])
        tIntraAttOutput = targetText + \
            torch.tanh(
                self.targetWeight * targetText
                + self.contextWeight * tIntraAttOutput
            )
        '''
        text
        '''

        '''
        image
        '''
        iConAtt = [torch.exp(
            torch.tanh(targetImage+iContext))
            for iContext in iChunkList[:-1]
        ]
        iConAttSum = iConAtt[0] + iConAtt[1] + iConAtt[2]
        iIntraAttOutput = [
            (iConAtt[i]/iConAttSum)*iChunkList[i] for i in range(3)
        ]
        iIntraAttOutput = iIntraAttOutput[0] +\
            iIntraAttOutput[1]+iIntraAttOutput[2]
        iIntraAttOutput = targetImage + \
            torch.tanh(
                self.targetWeight * targetImage
                + self.contextWeight * iIntraAttOutput
            )
        '''
        image
        '''

        '''
        audio
        '''
        aConAtt = [torch.exp(
            torch.tanh(targetAudio+aContext))
            for aContext in aChunkList[:-1]
        ]
        aConAttSum = aConAtt[0] + aConAtt[1] + aConAtt[2]
        aIntraAttOutput = [
            (aConAtt[i]/aConAttSum)*aChunkList[i] for i in range(3)
        ]
        aIntraAttOutput = aIntraAttOutput[0] +\
            aIntraAttOutput[1]+aIntraAttOutput[2]
        aIntraAttOutput = targetAudio + \
            torch.tanh(
                self.targetWeight * targetAudio
                + self.contextWeight * aIntraAttOutput
            )
        '''
        audio
        '''
        # intra-modal attention mechanism

        # inter-modal attention mechanism
        textKey, textValue, textQuery = \
            tIntraAttOutput, tIntraAttOutput, tIntraAttOutput
        imageKey, imageValue, imageQuery = \
            iIntraAttOutput, iIntraAttOutput, iIntraAttOutput
        audioKey, audioValue, audioQuery = \
            aIntraAttOutput, aIntraAttOutput, aIntraAttOutput
        # print('audioQuery.shape:', audioQuery.shape)
        # print('textQuery.shape:', textQuery.shape)
        # print('imageQuery.shape:', imageQuery.shape)
        interTtoI, _ = self.interTtoI(
            query=textQuery, key=imageKey, value=imageValue)
        interItoT, _ = self.interItoT(
            query=imageQuery, key=textKey, value=textValue)
        interTtoA, _ = self.interTtoA(
            query=textQuery, key=audioKey, value=audioValue)
        interAtoT, _ = self.interAtoT(
            query=audioQuery, key=textKey, value=textValue)
        interItoA, _ = self.interItoA(
            query=imageQuery, key=audioKey, value=audioValue)
        interAtoI, _ = self.interAtoI(
            query=audioQuery, key=imageKey, value=imageValue)
        # torch.Size([64, 2, 512])
        # print(interTtoI.device)
        # print(interItoT.device)
        # print(interTtoA.device)
        # print(interAtoT.device)
        # print(interAtoI.device)
        # print(interItoA.device)
        # print(interTtoI.shape)
        # print(interItoT.shape)
        # print(interTtoA.shape)
        # print(interAtoT.shape)  # torch.Size([64, 4, 512])
        # print(interAtoI.shape)  # torch.Size([64, 4, 512])
        # print(interItoA.shape)
        ITCat = torch.cat([interTtoI, interItoT], dim=0)
        ATCat = torch.cat([interTtoA, interAtoT], dim=0)
        IACat = torch.cat([interAtoI, interItoA], dim=0)
        catFeature = torch.cat([ITCat, ATCat, IACat], dim=0)
        # torch.Size([128, 2, 512])
        # catFeature.shape [128*3, 2, 512]
        # inter-modal attention mechanism

        # decoder module
        flatten = nn.Flatten()
        # sentiment
        sentGRU, sentHidden = self.sentimentGRU(catFeature)
        sentAtt, _ = self.sentimentAtt(sentGRU, sentGRU, sentGRU)
        sentAtt = torch.transpose(sentAtt, dim0=0, dim1=1)
        sentAtt = flatten(sentAtt)
        sentOutput = self.sentSoftmax(
            self.sentimentDense(
                self.sentScaleDense(sentAtt)
            )
        )
        # sentiment
        # emotion
        sentTop1 = torch.topk(sentOutput, 1)[1]
        sentTop1 = sentTop1.repeat(1, 512)
        sentTop1 = torch.unsqueeze(sentTop1, 1)
        sentTop1 = torch.transpose(sentTop1, dim0=0, dim1=1)
        emoInput = torch.cat([catFeature, sentHidden, sentTop1], dim=0)
        emoGRU, emoHidden = self.emotionGRU(emoInput)
        emoAtt, _ = self.emotionAtt(emoGRU, emoGRU, emoGRU)
        emoAtt = torch.transpose(emoAtt, dim0=0, dim1=1)
        emoAtt = torch.cat([flatten(emoAtt), sentAtt], dim=1)
        emoOutput = self.emoSoftmax(
            self.emotionDense(
                self.emoScaleDense(emoAtt)
            )
        )
        # emotion
        # sarcasm
        emoTop1 = torch.topk(emoOutput, 1)[1]
        emoTop1 = emoTop1.repeat(1, 512)
        emoTop1 = torch.unsqueeze(emoTop1, 1)
        emoTop1 = torch.transpose(emoTop1, dim0=0, dim1=1)
        sarInput = torch.cat([catFeature, emoHidden, emoTop1], dim=0)
        sarGRU, _ = self.sarcasmGRU(sarInput)
        sarAtt, _ = self.sarcasmAtt(sarGRU, sarGRU, sarGRU)
        sarAtt = torch.transpose(sarAtt, dim0=0, dim1=1)
        sarAtt = torch.cat([flatten(sarAtt), emoAtt, sentAtt], dim=1)
        sarOutput = self.sarSoftmax(
            self.sarcasmDense(
                self.sarScaleDense(sarAtt)
            )
        )
        # sarcasm
        # decoder module
        return sarOutput, sentOutput, emoOutput


class TestModel(Module):
    def __init__(self):
        super(TestModel, self).__init__()
        self.dropout = Dropout(0.4)
        self.flatten = Flatten(1, -1)
        self.fc1 = Linear(768*2, 64, bias=True)
        self.fc2 = Linear(64, 16, bias=True)
        '''
        input_size hidden_size number_layers bidirectional
        '''
        self.textBiGRU = GRU(768, 256, 1, bidirectional=True)
        self.imageBiGRU = GRU(768, 256, 1, bidirectional=True)
        '''
        torch.Size([1, 1280, 15, 11])
        通过efficientnet网络提取的特征的形状
        '''
        self.avgPool = AvgPool3d((15, 11))
        self.sarSoftMax = Softmax(-1)
        self.sentSoftMax = Softmax(-1)
        self.emoSoftMax = Softmax(-1)
        self.sarDense = Linear(16, 2)
        self.sentDense = Linear(16, 3)
        self.emoDense = Linear(16, 9)
        self.scaleDense1 = Linear(
            844800,
            768,
            bias=True)
        self.scaleDense2 = Linear(
            196608,
            768,
            bias=True)

    def forward(self, text, image):
        textFlatten = self.flatten(text)
        imageFlatten = self.flatten(image)
        fc1 = F.relu(self.scaleDense2(textFlatten))
        fc2 = F.relu(self.scaleDense1(imageFlatten))
        concateFlatten = torch.cat((fc1, fc2), dim=-1)
        fc1 = F.relu(self.fc1(concateFlatten))
        fc2 = F.relu(self.fc2(fc1))
        fc2 = self.dropout(fc2)
        sarcasm = self.sarDense(fc2)
        sentiment = self.sentDense(fc2)
        emotion = self.emoDense(fc2)
        return sarcasm, sentiment, emotion


if __name__ == '__main__':
    data = MustardDataset(datatye='train')
    data_loader = DataLoader(
        data,
        batch_size=6,
        shuffle=True,
        pin_memory=True)
    # model = M2Model(batchsize=2).to(device)
    model = M2Model()
    lossFun = nn.MSELoss()
    # print(model)
    epochs = 10
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)

    total = sum([param.nelement() for param in model.parameters()])
    print("Number of parameter: %.2fM" % (total/1e6))

    device_ids = [0, 1]
    model = torch.nn.DataParallel(model, device_ids=device_ids)
    # if torch.cuda.device_count() > 1:
    #     print("Use", torch.cuda.device_count(), 'gpus')
    #     model = nn.DataParallel(model)

    model.cuda()

    # modelsize(model, data_loader)
    for _ in range(epochs):
        print('epoch:', _)
        for batch in data_loader:
            model.train()
            # textInput = batch[0][0].to(device)
            # imageInput = batch[0][1].to(device)
            # sarLabel = batch[1][0].to(torch.float32).to(device)
            # sentLabel = batch[1][1].to(torch.float32).to(device)
            # emoLabel = batch[1][2].to(torch.float32).to(device)
            textInput = batch[0][0].cuda()
            imageInput = batch[0][1].cuda()
            tWavPath = batch[0][2]
            cWavPath = batch[0][3]
            sarLabel = batch[1][0].to(torch.float32).cuda()
            sentLabel = batch[1][1].to(torch.float32).cuda()
            emoLabel = batch[1][2].to(torch.float32).cuda()
            # print(sarLabel.shape)
            # if (use_gpu):
            #     textInput, imageInput = textInput.cuda(), imageInput.cuda()
            #     sarLabel, sentLabel, emoLabel =\
            #         sarLabel.cuda(), sentLabel.cuda(), emoLabel.cuda()

            sar, sent, emo = model(textInput, imageInput, tWavPath, cWavPath)
            sar = sar.to(torch.float32)
            sent = sent.to(torch.float32)
            emo = emo.to(torch.float32)

            loss1 = lossFun(sar, sarLabel)
            loss2 = lossFun(sent, sentLabel)
            loss3 = lossFun(emo, emoLabel)
            loss = (loss1 + loss2 + loss3)/3
            # if(use_gpu):
            #     loss = loss.cpu()
            print('loss', loss.item())
            loss.backward()
            # torch.cuda.empty_cache()
            optimizer.step()
            model.zero_grad()
