import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import matplotlib.ticker as ticker
import torch
from m2model_train import M2Model 

def test(input, name):
    a = input
    b = a.softmax(dim=1)
    c = a.softmax(dim=0).transpose(0, 1)
    print(a, '\n',  b, '\n', c)
    d = b.matmul(c)
    print(d)

    d = d.numpy()

    variables = range(1,129)
    labels = range(1,129)

    df = pd.DataFrame(d, columns=variables, index=labels)

    fig = plt.figure()

    ax = fig.add_subplot(111)

    cax = ax.matshow(df, interpolation='nearest', cmap='hot_r')
    fig.colorbar(cax)

    tick_spacing = 16
    ax.xaxis.set_major_locator(ticker.MultipleLocator(tick_spacing))
    ax.yaxis.set_major_locator(ticker.MultipleLocator(tick_spacing))
    # plt.yticks([]) 
    # plt.xticks([]) 

    # 设置坐标
    ax.set_xticklabels([''] + list(df.columns))
    ax.set_yticklabels([''] + list(df.index))
        
    f = plt.gcf()  #获取当前图像
    f.savefig("attentionmap/"+name+".png")
    f.clear()


def generateMap(statePATH):
    batchsize = 32
    model = M2Model(batchsize=batchsize).cuda()
    # model.load_state_dict(torch.load(statePATH))
    model = torch.load(statePATH)
    # print(type(model))
    # print(model)
    print(model.state_dict()['textEncodeAtt.out_proj.weight'].shape)
    weights = {}
    weights['imageEncodeAtt'] = model.state_dict()['imageEncodeAtt.out_proj.weight'].cpu().detach()
    weights['textEncodeAtt'] = model.state_dict()['textEncodeAtt.out_proj.weight'].cpu().detach()
    weights['audioEncodeAtt'] = model.state_dict()['audioEncodeAtt.out_proj.weight'].cpu().detach()
    weights['interTtoI'] = model.state_dict()['interTtoI.out_proj.weight'].cpu().detach()
    weights['interItoT'] = model.state_dict()['interItoT.out_proj.weight'].cpu().detach()
    weights['interTtoA'] = model.state_dict()['interTtoA.out_proj.weight'].cpu().detach()
    weights['interAtoT'] = model.state_dict()['interAtoT.out_proj.weight'].cpu().detach()
    weights['interAtoI'] = model.state_dict()['interAtoI.out_proj.weight'].cpu().detach()
    weights['interItoA'] = model.state_dict()['interItoA.out_proj.weight'].cpu().detach()
    weights['interItoA'] = model.state_dict()['interItoA.out_proj.weight'].cpu().detach()
    weights['interItoA'] = model.state_dict()['interItoA.out_proj.weight'].cpu().detach()
    weights['sentimentAtt'] = model.state_dict()['sentimentAtt.out_proj.weight'].cpu().detach()
    weights['emotionAtt'] = model.state_dict()['emotionAtt.out_proj.weight'].cpu().detach()
    weights['sarcasmAtt']= model.state_dict()['sarcasmAtt.out_proj.weight'].cpu().detach()
    for item in weights:
        test(weights[item], item)
    # weight1 = model.state_dict()['textEncodeAtt.out_proj.weight'].cpu().detach()
    # print(weight1.shape)
    # test(weight1, name='textEncodeAtt.out_proj.weight')

if __name__=="__main__":
    statePATH = 'statedict/best_textremovetext_model.pt'
    generateMap(statePATH)