# from torch.nn.modules import activation
from os import TMP_MAX
from ExpDataset import MustardDataset
# import torch.nn.functional as F
import torch
from torch import nn
from torch.nn import Module
from torch.nn import Dropout, Flatten, Linear,\
    Softmax, GRU, AvgPool3d, MultiheadAttention
from torch.utils.data import DataLoader, dataset
from transformers import AlbertModel, AlbertConfig
import numpy as np
from sklearn.metrics import f1_score, accuracy_score
from torch.autograd import Variable
import logging
# from torchviz import make_dot

# num_gpus = torch.cuda.device_count()
# device = torch.device('cuda' if num_gpus > 0 else 'cpu')
# device = torch.device('cuda:0 1')
# print(device)


class M2Model(Module):
    def __init__(self, batchsize):
        super(M2Model, self).__init__()
        # feature process
        # self.albertModel = \
            # AlbertModel.from_pretrained('./albert-base-v2').cuda()
        # self.config = AlbertConfig.from_pretrained('./albert-base-v2')
        self.vggLinear = Linear(in_features=1, out_features=24, bias=True)
        self.vggAct = nn.Tanh()

        self.textLinear = Linear(in_features=12, out_features=24, bias=True)
        self.textAct = nn.Tanh()
        # self.avgPool = AvgPool3d((270, 2, 2), stride=(43, 1, 1))
        # self.avgPoolFlatten = nn.Flatten(start_dim=-2)
        # feature process

        # encoderGRU
        self.textBiGRU = GRU(
            input_size=768,
            hidden_size=64,
            num_layers=1,
            batch_first=True,
            bidirectional=True)

        self.imageBiGRU = GRU(
            input_size=140,
            hidden_size=64,
            num_layers=1,
            batch_first=True,
            bidirectional=True)

        self.audioBiGRU = GRU(
            input_size=128,
            hidden_size=64,
            num_layers=1,
            batch_first=True,
            bidirectional=True)
        # encoderGRU

        # intra inter modal component
        self.textEncodeAtt = MultiheadAttention(128, 1)
        self.imageEncodeAtt = MultiheadAttention(128, 1)
        self.audioEncodeAtt = MultiheadAttention(128, 1)

        self.targetWeight = nn.Parameter(torch.Tensor([0.5]))
        self.contextWeight = nn.Parameter(torch.Tensor([0.5]))

        self.interTtoI = MultiheadAttention(
            128, 4)
        self.interItoT = MultiheadAttention(
            128, 4)
        self.interTtoA = MultiheadAttention(
            128, 4)
        self.interAtoT = MultiheadAttention(
            128, 4)
        self.interAtoI = MultiheadAttention(
            128, 4)
        self.interItoA = MultiheadAttention(
            128, 4)
        # intra inter modal component

        # decoder
        self.sentimentGRU = GRU(
            input_size=128,
            hidden_size=128,
            num_layers=1,
            batch_first=False)
        self.emotionGRU = GRU(
            input_size=128,
            hidden_size=128,
            num_layers=1,
            batch_first=False)
        self.sarcasmGRU = GRU(
            input_size=128,
            hidden_size=128,
            num_layers=1,
            batch_first=False)
        self.sentimentAtt = MultiheadAttention(128, 1)
        self.emotionAtt = MultiheadAttention(128, 1)
        self.sarcasmAtt = MultiheadAttention(128, 1)

        self.directSent = nn.Linear(
            in_features=9472, out_features=3)
        self.sentBN = nn.BatchNorm1d(9472)

        self.directEmo = nn.Linear(
            in_features=19200, out_features=9)
        self.emoBN = nn.BatchNorm1d(19200)

        self.directSar = nn.Linear(
            in_features=28928, out_features=2)
        self.sarBN = nn.BatchNorm1d(28928)

        self.sarScaleAct = nn.Tanh()
        self.dropout = nn.Dropout(p=0.4)
        # decoder

    def forward(self, text, image, tWavFea, cWavFea):
        '''
        text ([2, 4, 24]) batchsize, uttnumber, wordnumber
        image ([2, 4, 3, 480, 360]) batchsize, picnumber, channle, x, y
        tWavPath ([11, 2, 1, 96, 64]) wavlen, barchsize, 1, x, y
        cWavPath ([20, 2, 1, 96, 64]) wavlen, barchsize, 1, x, y
        '''
        # batchsize = text.shape[0]
        contextsize = text.shape[1]

        # bert
        text = text
        # torch.Size([2, 4, 24, 768]) 并且现在是有梯度的
        # ([2, 4, 12, 768]) 并且现在是有梯度的
        # bert

        # efficient-net
        image = image
        # torch.Size([2, 4, 24, 140])
        # efficient-net

        # vggish
        # 为测试模型先去掉扩充音频特征的线性层
        tWavPath = torch.transpose(tWavFea, dim0=-1, dim1=-2)
        cWavPath = torch.transpose(cWavFea, dim0=-1, dim1=-2)
        tAudioFeature = self.vggAct(self.vggLinear(tWavPath))
        cAudioFeature = self.vggAct(self.vggLinear(cWavPath))
        tAudioFeature = torch.transpose(tAudioFeature, dim0=-1, dim1=-2)
        cAudioFeature = torch.transpose(cAudioFeature, dim0=-1, dim1=-2)
        # 为测试模型先去掉扩充音频特征的线性层
        audio = torch.squeeze(
            torch.cat([tWavFea, cWavFea], dim=1), dim=1)
        file = open('../../log/runninglog/audio.txt', 'a')
        for i in audio:
            for ii in i:
                file.write(str(tWavFea))
                file.write('\n')
        file.close()
        ######

        ######

        # audio torch.Size([2, 4, 24, 128])
        # vggish

        textChunks = torch.chunk(text, contextsize, 1)
        imageChunks = torch.chunk(image, contextsize, 1)
        audioChunks = torch.chunk(audio, contextsize, 1)
        tChunkList = []
        iChunkList = []
        aChunkList = []
        thnList = []
        ihnList = []
        ahnList = []
        tEncoderAttWeight = []
        iEncoderAttWeight = []
        aEncoderAttWeight = []

        # multi-modal encoder
        for tChunk in textChunks:
            '''
            文本的使用gru学习关联关系的部分
            '''
            # torch.Size([2, 64, 768])
            tChunk = torch.squeeze(tChunk, dim=1)
            # tChunk -- torch.Size([2, 64, 256])
            tChunk, thn = self.textBiGRU(tChunk)
            thnList.append(thn)
            '''
            文本的使用attention学习最后的句子表示的encoder部分
            '''
            query = torch.transpose(tChunk, dim0=0, dim1=1)
            key = torch.transpose(tChunk, dim0=0, dim1=1)
            value = torch.transpose(tChunk, dim0=0, dim1=1)
            # textAttnOutput -- torch.Size([64, 2, 256])
            textAttnOutput, textAttnOutputWeights = \
                self.textEncodeAtt(query, key, value)
            tChunkList.append(textAttnOutput)
            tEncoderAttWeight.append(textAttnOutputWeights)
            # textAttnOutput torch.Size([24, 2, 256])
            # textAttnOutputWeights torch.Size([2, 24, 24])

        for iChunk in imageChunks:
            '''
            图像的使用gru学习关联关系的部分
            '''
            # torch.Size([2, 64, 140])
            iChunk = torch.squeeze(iChunk, dim=1)
            # torch.Size([2, 64, 256])
            iChunk, ihn = self.imageBiGRU(iChunk)
            ihnList.append(ihn)
            '''
            图像的使用attention学习最后的句子表示的encoder部分
            '''
            query = torch.transpose(iChunk, dim0=0, dim1=1)
            key = torch.transpose(iChunk, dim0=0, dim1=1)
            value = torch.transpose(iChunk, dim0=0, dim1=1)
            # imageAttnOutput -- torch.Size([64, 2, 256])
            imageAttnOutput, imageAttnOutputWeights = \
                self.imageEncodeAtt(query, key, value)
            iChunkList.append(imageAttnOutput)
            iEncoderAttWeight.append(imageAttnOutputWeights)
            # 对求得的一个句子的表示求平均值，得到表示一个句子的向量表示（64,batchsize,256->(batchsize,1,256)
            # imageAttnOutput torch.Size([24, 2, 256])
            # imageAttnOutputWeights torch.Size([2, 24, 24])

        for aChunk in audioChunks:
            aChunk = torch.squeeze(aChunk, dim=1)
            aChunk, ahn = self.audioBiGRU(aChunk)
            ahnList.append(ahn)
            query = torch.transpose(aChunk, dim0=0, dim1=1)
            key = torch.transpose(aChunk, dim0=0, dim1=1)
            value = torch.transpose(aChunk, dim0=0, dim1=1)
            audioAttnOutput, audioAttnOutputWeights = \
                self.audioEncodeAtt(query, key, value)
            aChunkList.append(audioAttnOutput)
            aEncoderAttWeight.append(audioAttnOutputWeights)
            # audioAttnOutput torch.Size([24, 2, 256])
            # audioAttnOutputWeights torch.Size([2, 24, 24])
        # multi-modal encoder

        # intra-modal attention mechanism
        # 对求出的目标语句和上下文语句进行 拼接式注意力机制 得出表示一个对话的表示
        # 这里的注意力机制是将目标语句和上下文语句分别拼接hi（i 1-3）起来求和sum
        # 在分别求每个上下文语句的 hi/sum 作为权重然后再进行加权和
        targetText = tChunkList[-1]
        targetImage = iChunkList[-1]
        targetAudio = aChunkList[-1]

        '''
        text
        '''
        tConAtt = [torch.exp(
            torch.tanh(targetText+tContext)+1e-7)
            for tContext in tChunkList[:-1]
        ]
        tConAttSum = tConAtt[0] + tConAtt[1] + tConAtt[2]
        tIntraAttOutput = [
            (tConAtt[i]/tConAttSum)*tChunkList[i] for i in range(3)
        ]
        tIntraAttOutput = tIntraAttOutput[0] +\
            tIntraAttOutput[1]+tIntraAttOutput[2]
        tIntraAttOutput = targetText + \
            torch.tanh(
                self.targetWeight * targetText
                + self.contextWeight * tIntraAttOutput
            )
        # torch.Size([24, 2, 256])
        '''
        text
        '''

        '''
        image
        '''
        iConAtt = [torch.exp(
            torch.tanh(targetImage+iContext)+1e-7)
            for iContext in iChunkList[:-1]
        ]
        iConAttSum = iConAtt[0] + iConAtt[1] + iConAtt[2]
        iIntraAttOutput = [
            (iConAtt[i]/iConAttSum)*iChunkList[i] for i in range(3)
        ]
        iIntraAttOutput = iIntraAttOutput[0] +\
            iIntraAttOutput[1]+iIntraAttOutput[2]
        iIntraAttOutput = targetImage + \
            torch.tanh(
                self.targetWeight * targetImage
                + self.contextWeight * iIntraAttOutput
            )
        # torch.Size([24, 2, 256])
        '''
        image
        '''

        '''
        audio
        '''
        aConAtt = [torch.exp(
            torch.tanh(targetAudio+aContext)+1e-7)
            for aContext in aChunkList[:-1]
        ]
        aConAttSum = aConAtt[0] + aConAtt[1] + aConAtt[2]
        aIntraAttOutput = [
            (aConAtt[i]/aConAttSum)*aChunkList[i] for i in range(3)
        ]
        aIntraAttOutput = aIntraAttOutput[0] +\
            aIntraAttOutput[1]+aIntraAttOutput[2]
        aIntraAttOutput = targetAudio + \
            torch.tanh(
                self.targetWeight * targetAudio
                + self.contextWeight * aIntraAttOutput
            )
        # torch.Size([24, 2, 256])
        '''
        audio
        '''
        # intra-modal attention mechanism

        # inter-modal attention mechanism
        textKey, textValue, textQuery = \
            tIntraAttOutput, tIntraAttOutput, tIntraAttOutput
        imageKey, imageValue, imageQuery = \
            iIntraAttOutput, iIntraAttOutput, iIntraAttOutput
        audioKey, audioValue, audioQuery = \
            aIntraAttOutput, aIntraAttOutput, aIntraAttOutput
        interTtoI, _ = self.interTtoI(
            query=textQuery, key=imageKey, value=imageValue)
        interItoT, _ = self.interItoT(
            query=imageQuery, key=textKey, value=textValue)
        interTtoA, _ = self.interTtoA(
            query=textQuery, key=audioKey, value=audioValue)
        interAtoT, _ = self.interAtoT(
            query=audioQuery, key=textKey, value=textValue)
        interItoA, _ = self.interItoA(
            query=imageQuery, key=audioKey, value=audioValue)
        interAtoI, _ = self.interAtoI(
            query=audioQuery, key=imageKey, value=imageValue)
        # torch.Size([24, 2, 256])
        ITCat = torch.cat([interTtoI, interItoT], dim=0)
        ATCat = torch.cat([interTtoA, interAtoT], dim=0)
        IACat = torch.cat([interAtoI, interItoA], dim=0)
        # print("ITCat.sahpe:", ITCat.shape)
        # print("ATCat.sahpe:", ATCat.shape)
        # print("IACat.sahpe:", IACat.shape)
        # torch.Size([48, 2, 256])
        catFeature = torch.cat([ITCat, ATCat, IACat], dim=0)
        # print('catFeature.shape:', catFeature.shape)
        # catFeature.shape [144, 2, 256]
        # inter-modal attention mechanism

        # decoder module
        flatten = nn.Flatten()
        # sentiment
        sentGRU, sentHidden = self.sentimentGRU(catFeature)
        sentAtt, _ = self.sentimentAtt(sentGRU, sentGRU, sentGRU)
        sentAtt = torch.transpose(sentAtt, dim0=0, dim1=1)
        sentAttFlatten = flatten(sentAtt)
        # print('sentAtt:', sentAtt.shape)
        sentOutput = self.sentBN(sentAttFlatten)
        sentOutput = self.directSent(sentOutput)
        # sentiment

        # # emotion
        sentTop1 = torch.topk(sentOutput, 1)[1]
        sentTop1 = sentTop1.repeat(1, 128)
        sentTop1 = torch.unsqueeze(sentTop1, 1)
        sentTop1 = torch.transpose(sentTop1, dim0=0, dim1=1)
        emoInput = torch.cat([catFeature, sentHidden, sentTop1], dim=0)
        emoGRU, emoHidden = self.emotionGRU(emoInput)
        emoAtt, _ = self.emotionAtt(emoGRU, emoGRU, emoGRU)
        emoAtt = torch.transpose(emoAtt, dim0=0, dim1=1)
        emoAttFlatten = torch.cat([flatten(sentAtt), flatten(emoAtt)], dim=1)
        # print('emoAtt:', emoAtt.shape)
        emoOutput = self.emoBN(emoAttFlatten)
        emoOutput = self.directEmo(emoOutput)
        # emotion

        # sarcasm
        emoTop1 = torch.topk(emoOutput, 1)[1]
        emoTop1 = emoTop1.repeat(1, 128)
        emoTop1 = torch.unsqueeze(emoTop1, 1)
        emoTop1 = torch.transpose(emoTop1, dim0=0, dim1=1)
        sarInput = torch.cat([catFeature, emoHidden, emoTop1], dim=0)
        sarGRU, _ = self.sarcasmGRU(sarInput)
        sarAtt, _ = self.sarcasmAtt(sarGRU, sarGRU, sarGRU)
        sarAtt = torch.transpose(sarAtt, dim0=0, dim1=1)
        sarAttFlatten = torch.cat([
            flatten(emoAtt), flatten(sentAtt), flatten(sarAtt)], dim=1)
        # print('sarAtt:', sarAtt.shape)
        sarOutput = self.sarBN(sarAttFlatten)
        sarOutput = self.directSar(sarOutput)
        # sarcasm

        # decoder module
        return sarOutput, sentOutput, emoOutput


def testModel(statePATH):
    testData = MustardDataset(datatye='test')
    batchsize = 32
    data_loader = DataLoader(
        testData,
        batch_size=batchsize,
        shuffle=True,
        pin_memory=True
        )

    model = M2Model(batchsize=batchsize).cuda()
    model.load_state_dict(
        torch.load(statePATH))
    model.eval()
    with torch.no_grad():
        outputsar, outputsent, outputemo = [], [], []
        tarsar, tarsent, taremo = [], [], []
        for batch in data_loader:
            textInput = batch[0][0].cuda().to(torch.float32)
            imageInput = batch[0][1].cuda().to(torch.float32)
            tWavPath = batch[0][2].cuda().to(torch.float32)
            cWavPath = batch[0][3].cuda().to(torch.float32)
            sarLabel = batch[1][0].to(torch.float32).cuda()
            sentLabel = batch[1][1].to(torch.float32).cuda()
            emoLabel = batch[1][2].to(torch.float32).cuda()
            sar, sent, emo = \
                model(textInput, imageInput, tWavPath, cWavPath)

            label_sar = np.argmax(
                sarLabel.cpu().detach().numpy(), axis=-1)
            label_sent = np.argmax(
                sentLabel.cpu().detach().numpy(), axis=-1)
            label_emo = np.argmax(
                emoLabel.cpu().detach().numpy(), axis=-1)
            pred_sar = np.argmax(
                sar.cpu().detach().numpy(), axis=1)
            pred_sent = np.argmax(
                sent.cpu().detach().numpy(), axis=1)
            pred_emo = np.argmax(
                emo.cpu().detach().numpy(), axis=1)
            outputsar.append(pred_sar)
            outputsent.append(pred_sent)
            outputemo.append(pred_emo)
            tarsar.append(label_sar)
            tarsent.append(label_sent)
            taremo.append(label_emo)

        outputsar = np.concatenate(
            np.array(outputsar, dtype=object))
        outputsent = np.concatenate(
            np.array(outputsent, dtype=object))
        outputemo = np.concatenate(
            np.array(outputemo, dtype=object))
        tarsar = np.concatenate(
            np.array(tarsar, dtype=object))
        tarsent = np.concatenate(
            np.array(tarsent, dtype=object))
        taremo = np.concatenate(
            np.array(taremo, dtype=object))

        # outputsar = np.concatenate(
        #     np.array(outputsar))
        # outputsent = np.concatenate(
        #     np.array(outputsent))
        # outputemo = np.concatenate(
        #     np.array(outputemo))
        # tarsar = np.concatenate(
        #     np.array(tarsar))
        # tarsent = np.concatenate(
        #     np.array(tarsent))
        # taremo = np.concatenate(
        #     np.array(taremo))

        sar_f1 = f1_score(
            tarsar, outputsar, average='micro')
        sent_f1 = f1_score(
            tarsent, outputsent, average='micro')
        emo_f1 = f1_score(
            taremo, outputemo, average='micro')
        sar_acc = accuracy_score(
            tarsar, outputsar)
        sent_acc = accuracy_score(
            tarsent, outputsent)
        emo_acc = accuracy_score(
            taremo, outputemo)
        print('test tarsar:', tarsar)
        print('test outputsar:', outputsar)
        print('test tarsent:', tarsent)
        print('test outputsent:', outputsent)
        print('test taremo:', taremo)
        print('test outputemo:', outputemo)
        logger.info(('test-result sar-f1:%f sent-f1:%f emo-f1:%f' +
                    'sar-acc:%f sent-acc:%f emo-acc:%f\n')
                    % (sar_f1, sent_f1, emo_f1,
                    sar_acc, sent_acc, emo_acc))


def trainEval():
    # logging.basicConfig(filemode='w')
    # logger = logging.getLogger(__name__)
    # logger.setLevel(level=logging.INFO)
    # handler = logging.FileHandler(
    #     "../../log/m2modelTextBert_imageAudioFromFile.txt")
    # handler.setLevel(logging.INFO)
    # formatter = logging.Formatter(
    #     '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    # handler.setFormatter(formatter)
    # logger.addHandler(handler)

    # logger.info("**********Start print log**********")

    data = MustardDataset(datatye='train')
    valData = MustardDataset(datatye='dev')
    batchsize = 128
    data_loader = DataLoader(
        data,
        batch_size=batchsize,
        shuffle=True,
        pin_memory=True
        )
    val_loader = DataLoader(
        valData,
        batch_size=30,
        shuffle=True,
        pin_memory=True,
        )
    model = M2Model(batchsize=batchsize).cuda()
    for m in model.modules():
        if isinstance(m, (Linear)):
            nn.init.xavier_uniform_(m.weight)
    # # 绘制梯度图
    # net_struct = make_dot(model)
    # net_struct.render("model_struct", view=False)

    # lossFun = nn.MSELoss()
    lossFun = nn.CrossEntropyLoss().cuda()
    lossFun_val = nn.CrossEntropyLoss().cuda()
    # print(model)
    epochs = 15

    optimizer = torch.optim.Adam(
        model.parameters(), lr=0.001, weight_decay=0.015)
    # optimizer = torch.optim.RMSprop(model.parameters(), lr=0.1)

    total = sum([param.nelement() for param in model.parameters()])
    print("Number of parameter: %.2fM" % (total/1e6))

    statePATH = 'statedict/best_textremovetext_state_dice.pt'
    modelPATH = 'statedict/best_textremovetext_model.pt'

    for _ in range(epochs):
        logger.info('epoch:'+str(_))
        train_step = 0
        for batch in data_loader:
            train_step += 1
            model.train()
            textInput = batch[0][0].cuda().to(torch.float32)
            imageInput = batch[0][1].to(torch.float32).cuda()
            tWavPath = batch[0][2].to(torch.float32).cuda()
            cWavPath = batch[0][3].to(torch.float32).cuda()
            sarLabel = batch[1][0].to(torch.float32).cuda()
            sentLabel = batch[1][1].to(torch.float32).cuda()
            emoLabel = batch[1][2].to(torch.float32).cuda()

            textInput = Variable(textInput, requires_grad=True)
            imageInput = Variable(imageInput, requires_grad=True)
            tWavPath = Variable(tWavPath, requires_grad=True)
            cWavPath = Variable(cWavPath, requires_grad=True)
            sarLabel = Variable(sarLabel, requires_grad=True)
            sentLabel = Variable(sentLabel, requires_grad=True)
            emoLabel = Variable(emoLabel, requires_grad=True)

            sar, sent, emo = \
                model(textInput, imageInput, tWavPath, cWavPath)
            sar = sar.to(torch.float32)
            sent = sent.to(torch.float32)
            emo = emo.to(torch.float32)

            sarArgmax = torch.argmax(sarLabel, dim=-1)
            sentArgmax = torch.argmax(sentLabel, dim=-1)
            emoArgmax = torch.argmax(emoLabel, dim=-1)
            loss1 = lossFun(sar, sarArgmax)
            loss2 = lossFun(sent, sentArgmax)
            loss3 = lossFun(emo, emoArgmax)
            loss = (loss1 + loss2 + loss3)/3

            # print('sarArgmax:', sarArgmax)
            # print('sar:', torch.argmax(sar, dim=-1))
            # print('sentArgmax:', sentArgmax)
            # print('sent:', torch.argmax(sent, dim=-1))
            # print('emoArgmax:', emoArgmax)
            # print('emo:', torch.argmax(emo, dim=-1))
            loss.requires_grad_(True)
            logger.info('loss1:%f loss2:%f loss3:%f loss:%f\n'
                        % (loss1.item(),
                            loss2.item(),
                            loss3.item(),
                            loss.item()))

            if train_step % 2 == 0:
                label_sar = np.argmax(
                    sarLabel.cpu().detach().numpy(), axis=-1)
                label_sent = np.argmax(
                    sentLabel.cpu().detach().numpy(), axis=-1)
                label_emo = np.argmax(
                    emoLabel.cpu().detach().numpy(), axis=-1)
                pred_sar = np.argmax(
                    sar.cpu().detach().numpy(), axis=1)
                pred_sent = np.argmax(
                    sent.cpu().detach().numpy(), axis=1)
                pred_emo = np.argmax(
                    emo.cpu().detach().numpy(), axis=1)

                # logger.info('label_sar:'+str(label_sar))
                # logger.info('pred_sar:'+str(pred_sar))
                # logger.info('label_sent:'+str(label_sent))
                # logger.info('pred_sent:'+str(pred_sent))
                # logger.info('label_emo:'+str(label_emo))
                # logger.info('pred_emo:'+str(pred_emo))
                sar_f1 = f1_score(label_sar, pred_sar, average='micro')
                sent_f1 = f1_score(label_sent, pred_sent, average='micro')
                emo_f1 = f1_score(label_emo, pred_emo, average='micro')
                sar_acc = accuracy_score(
                    label_sar, pred_sar)
                sent_acc = accuracy_score(
                    label_sent, pred_sent)
                emo_acc = accuracy_score(
                    label_emo, pred_emo)
                logger.info(('train result sar-f1:%f sent-f1:%f ' +
                            'emo-f1:%f sar-acc:%f sent-acc:%f emo-acc:%f\n')
                            % (sar_f1, sent_f1, emo_f1,
                            sar_acc, sent_acc, emo_acc))

                model.eval()
                with torch.no_grad():
                    outputsar, outputsent, outputemo = [], [], []
                    tarsar, tarsent, taremo = [], [], []
                    for batch in val_loader:
                        textInput = batch[0][0].cuda().to(torch.float32)
                        imageInput = batch[0][1].cuda().to(torch.float32)
                        tWavPath = batch[0][2].cuda().to(torch.float32)
                        cWavPath = batch[0][3].cuda().to(torch.float32)
                        sarLabel = batch[1][0].to(torch.float32).cuda()
                        sentLabel = batch[1][1].to(torch.float32).cuda()
                        emoLabel = batch[1][2].to(torch.float32).cuda()
                        sar, sent, emo = \
                            model(textInput, imageInput, tWavPath, cWavPath)

                        sarArgmax = torch.argmax(sarLabel, dim=-1)
                        sentArgmax = torch.argmax(sentLabel, dim=-1)
                        emoArgmax = torch.argmax(emoLabel, dim=-1)
                        loss1_val = lossFun_val(sar, sarArgmax)
                        loss2_val = lossFun_val(sent, sentArgmax)
                        loss3_val = lossFun_val(emo, emoArgmax)
                        loss_val = (loss1_val + loss2_val + loss3_val)/3
                        logger.info('val loss1:%f loss2:%f loss3:%f loss:%f\n'
                                % (loss1_val.item(),
                                    loss2_val.item(),
                                    loss3_val.item(),
                                    loss_val.item()))

                        label_sar = np.argmax(
                            sarLabel.cpu().detach().numpy(), axis=-1)
                        label_sent = np.argmax(
                            sentLabel.cpu().detach().numpy(), axis=-1)
                        label_emo = np.argmax(
                            emoLabel.cpu().detach().numpy(), axis=-1)
                        pred_sar = np.argmax(
                            sar.cpu().detach().numpy(), axis=1)
                        pred_sent = np.argmax(
                            sent.cpu().detach().numpy(), axis=1)
                        pred_emo = np.argmax(
                            emo.cpu().detach().numpy(), axis=1)
                        outputsar.append(pred_sar)
                        outputsent.append(pred_sent)
                        outputemo.append(pred_emo)
                        tarsar.append(label_sar)
                        tarsent.append(label_sent)
                        taremo.append(label_emo)

                    # outputsar = np.concatenate(
                    #     np.array(outputsar, dtype=object))
                    # outputsent = np.concatenate(
                    #     np.array(outputsent, dtype=object))
                    # outputemo = np.concatenate(
                    #     np.array(outputemo, dtype=object))
                    # tarsar = np.concatenate(
                    #     np.array(tarsar, dtype=object))
                    # tarsent = np.concatenate(
                    #     np.array(tarsent, dtype=object))
                    # taremo = np.concatenate(
                    #     np.array(taremo, dtype=object))

                    outputsar = np.concatenate(
                        np.array(outputsar))
                    outputsent = np.concatenate(
                        np.array(outputsent))
                    outputemo = np.concatenate(
                        np.array(outputemo))
                    tarsar = np.concatenate(
                        np.array(tarsar))
                    tarsent = np.concatenate(
                        np.array(tarsent))
                    taremo = np.concatenate(
                        np.array(taremo))
                    # print('tarsar:', tarsar)
                    # print('outputsar:', outputsar)
                    # print('tarsent:', tarsent)
                    # print('outputsent:', outputsent)
                    # print('taremo:', taremo)
                    # print('outputemo:', outputemo)
                    sar_f1 = f1_score(
                        tarsar, outputsar, average='micro')
                    sent_f1 = f1_score(
                        tarsent, outputsent, average='micro')
                    emo_f1 = f1_score(
                        taremo, outputemo, average='micro')
                    sar_acc = accuracy_score(
                        tarsar, outputsar)
                    sent_acc = accuracy_score(
                        tarsent, outputsent)
                    emo_acc = accuracy_score(
                        taremo, outputemo)
                    logger.info(('val-result sar-f1:%f sent-f1:%f emo-f1:%f' +
                                ' sar-acc:%f sent-acc:%f emo-acc:%f\n')
                                % (sar_f1, sent_f1, emo_f1,
                                sar_acc, sent_acc, emo_acc))

                    # if bestResult < (sar_acc+sent_acc+emo_acc):
                    #     bestResult = (sar_acc+sent_acc+emo_acc)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
    torch.save(model.state_dict(), statePATH)
    torch.save(model, modelPATH)


if __name__ == '__main__':
    logging.basicConfig(filemode='w')
    logger = logging.getLogger(__name__)
    logger.setLevel(level=logging.INFO)
    handler = logging.FileHandler(
        "log/m2modelTextBert_imageAudioFromFile.txt")
    handler.setLevel(logging.INFO)
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    logger.info("**********Start print log**********")
    statePATH = 'statedict/best_textremovetext_state_dice.pt'

    trainEval()

    testModel(statePATH)
